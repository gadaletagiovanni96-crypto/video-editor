'use strict';
/*
 * Editor Video
 * Tutto gira nel browser: anteprima su <canvas>, audio con Web Audio API,
 * esportazione con MediaRecorder (canvas + audio mixato).
 */

/* =========================================================
 * Utility
 * ======================================================= */
const $ = (s, r = document) => r.querySelector(s);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, p) => a + (b - a) * p;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const even = n => Math.round(n / 2) * 2;
let uid = 1;

function fmtTime(t) {
  t = Math.max(0, t || 0);
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${String(m).padStart(2, '0')}:${s.toFixed(1).padStart(4, '0')}`;
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
// Versione installata su Linux: il comando di avvio apre index.html?desktop=1.
// Solo lì compaiono i progetti salvati su file (menu File).
const DESKTOP = new URLSearchParams(location.search).has('desktop') && 'showDirectoryPicker' in window;

// Icona dal set definito in index.html
const icon = (name, cls = '') => `<svg class="ic ${cls}"><use href="#i-${name}"/></svg>`;

// Colora la parte "piena" dei cursori
function paintRange(el) {
  const min = Number(el.min) || 0, max = Number(el.max) || 100;
  const p = max > min ? (Number(el.value) - min) / (max - min) * 100 : 0;
  el.style.setProperty('--p', `${clamp(p, 0, 100)}%`);
}
const paintRanges = (root = document) => root.querySelectorAll('input[type=range]').forEach(paintRange);

let toastTimer;
function toast(msg, ms = 3000) {
  const el = $('#toast');
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), ms);
}

/* =========================================================
 * Animazioni foto (stile "Ken Burns" / Movie Maker), versione delicata.
 * s  = zoom relativo alla foto "intera" (1 = la foto tocca i bordi dello
 *      schermo; < 1 = un po' più piccola, con un margine nero)
 * dx/dy = spostamento in frazione dello schermo (0 = centrata).
 * Lo zoom non supera mai 1 e la posizione viene limitata ai bordi,
 * quindi la foto resta sempre visibile per intero.
 * ======================================================= */
const ANIMATIONS = {
  none:      { label: 'Nessuna (ferma)',             from: { s: 1,   dx: 0,     dy: 0 },     to: { s: 1,   dx: 0,     dy: 0 } },
  zoomIn:    { label: 'Avvicinamento lento',         from: { s: .9,  dx: 0,     dy: 0 },     to: { s: 1,   dx: 0,     dy: 0 } },
  zoomOut:   { label: 'Allontanamento lento',        from: { s: 1,   dx: 0,     dy: 0 },     to: { s: .9,  dx: 0,     dy: 0 } },
  panRight:  { label: 'Scivola verso destra',        from: { s: .93, dx: -.035, dy: 0 },     to: { s: .93, dx: .035,  dy: 0 } },
  panLeft:   { label: 'Scivola verso sinistra',      from: { s: .93, dx: .035,  dy: 0 },     to: { s: .93, dx: -.035, dy: 0 } },
  panDown:   { label: 'Scivola verso il basso',      from: { s: .93, dx: 0,     dy: -.035 }, to: { s: .93, dx: 0,     dy: .035 } },
  panUp:     { label: "Scivola verso l'alto",        from: { s: .93, dx: 0,     dy: .035 },  to: { s: .93, dx: 0,     dy: -.035 } },
  zoomInTL:  { label: 'Avvicinamento verso alto-sx', from: { s: .9,  dx: .02,   dy: .02 },   to: { s: .97, dx: -.015, dy: -.015 } },
  zoomInBR:  { label: 'Avvicinamento verso basso-dx', from: { s: .9, dx: -.02,  dy: -.02 },  to: { s: .97, dx: .015,  dy: .015 } },
  zoomOutTR: { label: 'Allontanamento da alto-dx',   from: { s: .97, dx: .015,  dy: -.015 }, to: { s: .9,  dx: -.02,  dy: .02 } },
  zoomOutBL: { label: 'Allontanamento da basso-sx',  from: { s: .97, dx: -.015, dy: .015 },  to: { s: .9,  dx: .02,   dy: -.02 } },
};
const MOVING_ANIMS = Object.keys(ANIMATIONS).filter(k => k !== 'none');
const randomAnim = () => MOVING_ANIMS[Math.floor(Math.random() * MOVING_ANIMS.length)];
const easeInOut = p => 0.5 - Math.cos(Math.PI * p) / 2;

/* =========================================================
 * Stato del progetto
 * ======================================================= */
const settings = {
  aspect: '16:9',
  quality: 720,
  fps: 30,
  fadeFromBlack: true,
  fadeToBlack: true,
  photoFit: 'contain',
  photoDuration: 4,
  transition: 1,
  defaultAnim: 'random',
  smoothAnim: true,
  optimizeVideos: true,
  animStrength: 1,
};
const clips = [];  // foto e video in sequenza
const music = [];  // tracce musicali
let layout = [];   // [{clip, start, dur, tr}]
let total = 0;
let selected = null; // { kind: 'clip' | 'music', id }
let pps = 40;        // pixel per secondo nella timeline

const canvas = $('#preview');
const g = canvas.getContext('2d');
const pool = $('#mediaPool');

/* =========================================================
 * Audio (Web Audio API)
 * ======================================================= */
let actx = null, master = null, exportDest = null;
function ensureAudio() {
  if (actx) return;
  actx = new (window.AudioContext || window.webkitAudioContext)();
  master = actx.createGain();
  master.connect(actx.destination);
  exportDest = actx.createMediaStreamDestination();
  master.connect(exportDest);
}
function connectMedia(el) {
  ensureAudio();
  const src = actx.createMediaElementSource(el);
  const gain = actx.createGain();
  gain.gain.value = 0;
  src.connect(gain).connect(master);
  return { src, gain };
}
function setGain(node, v) {
  if (!node || !actx) return;
  const p = node.gain;
  if (Math.abs(p.value - v) < 0.001) return;
  p.setTargetAtTime(v, actx.currentTime, 0.015);
}

/* =========================================================
 * Caricamento file
 * ======================================================= */
function kindOf(f) {
  const t = f.type || '';
  if (t.startsWith('image/')) return 'image';
  if (t.startsWith('video/')) return 'video';
  if (t.startsWith('audio/')) return 'audio';
  const ext = (f.name.split('.').pop() || '').toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif'].includes(ext)) return 'image';
  if (['mp4', 'mov', 'webm', 'mkv', 'm4v', 'ogv', '3gp'].includes(ext)) return 'video';
  if (['mp3', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'flac', 'opus'].includes(ext)) return 'audio';
  return null;
}

function loadMediaEl(url, tag) {
  return new Promise((resolve, reject) => {
    const el = document.createElement(tag);
    el.preload = 'auto';
    if (tag === 'video') el.playsInline = true;
    const okEvent = tag === 'video' ? 'loadeddata' : 'loadedmetadata';
    const ok = () => { done(); resolve(el); };
    const ko = () => { done(); reject(new Error('formato non supportato dal browser')); };
    const done = () => { el.removeEventListener(okEvent, ok); el.removeEventListener('error', ko); };
    el.addEventListener(okEvent, ok);
    el.addEventListener('error', ko);
    el.src = url;
  });
}

// Alcuni file (es. WebM registrati dal browser) non dichiarano la durata.
async function fixDuration(el) {
  if (isFinite(el.duration) && el.duration > 0) return;
  await new Promise(resolve => {
    const t = setTimeout(resolve, 4000);
    const h = () => {
      if (isFinite(el.duration)) { clearTimeout(t); el.removeEventListener('durationchange', h); resolve(); }
    };
    el.addEventListener('durationchange', h);
    el.currentTime = 1e7;
  });
  el.currentTime = 0;
  if (!isFinite(el.duration)) throw new Error('impossibile leggere la durata');
}

function waitSeek(el, t) {
  return new Promise(resolve => {
    if (Math.abs(el.currentTime - t) < 0.001 && !el.seeking) return resolve();
    const h = () => { el.removeEventListener('seeked', h); resolve(); };
    el.addEventListener('seeked', h);
    el.currentTime = t;
    setTimeout(h, 3000);
  });
}

function makeThumb(src, w, h) {
  const c = document.createElement('canvas');
  c.width = 160; c.height = 90;
  const x = c.getContext('2d');
  x.fillStyle = '#000'; x.fillRect(0, 0, 160, 90);
  const k = Math.max(160 / w, 90 / h);
  x.drawImage(src, (160 - w * k) / 2, (90 - h * k) / 2, w * k, h * k);
  return c.toDataURL('image/jpeg', 0.7);
}

async function createImageClip(file) {
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.src = url;
  await img.decode();
  const w = img.naturalWidth, h = img.naturalHeight;
  // Riduce le foto molto grandi per un'anteprima/export più fluidi
  let src = img;
  const MAX = 2560;
  if (Math.max(w, h) > MAX && window.createImageBitmap) {
    const k = MAX / Math.max(w, h);
    try {
      src = await createImageBitmap(img, { resizeWidth: Math.round(w * k), resizeHeight: Math.round(h * k), resizeQuality: 'high' });
    } catch { src = img; }
  }
  return {
    id: uid++, type: 'image', name: file.name, url, src, w, h,
    thumb: makeThumb(img, w, h),
    duration: settings.photoDuration,
    transition: settings.transition,
    anim: settings.defaultAnim === 'random' ? randomAnim() : settings.defaultAnim,
    fit: photoFitFor(w, h),
  };
}

async function createVideoClip(name, url, thumb = null) {
  const el = await loadMediaEl(url, 'video');
  await fixDuration(el);
  pool.appendChild(el);
  const audio = connectMedia(el);
  el.addEventListener('seeked', () => { if (!player.playing) requestRender(); });
  if (!thumb) {
    await waitSeek(el, Math.min(1, el.duration * 0.2));
    thumb = makeThumb(el, el.videoWidth, el.videoHeight);
    await waitSeek(el, 0);
  }
  return {
    id: uid++, type: 'video', name, url, el, audio, thumb,
    w: el.videoWidth, h: el.videoHeight,
    srcDuration: el.duration, in: 0, out: el.duration,
    muted: false, volume: 1,
    transition: settings.transition, fit: 'contain',
  };
}

async function createMusic(name, url) {
  const el = await loadMediaEl(url, 'audio');
  await fixDuration(el);
  pool.appendChild(el);
  const audio = connectMedia(el);
  const lastEnd = music.reduce((m, x) => Math.max(m, x.start + (x.out - x.in)), 0);
  return {
    id: uid++, type: 'music', name, url, el, audio,
    srcDuration: el.duration, in: 0, out: el.duration,
    start: lastEnd, volume: 0.8, fadeIn: 0, fadeOut: 2,
  };
}

let loadingCount = 0;
async function addFiles(fileList) {
  ensureAudio();
  const files = [...fileList];
  let added = 0, lastSel = null;
  loadingCount += files.length;
  for (const f of files) {
    const kind = kindOf(f);
    toast(`Caricamento: ${f.name}…`, 60000);
    try {
      if (kind === 'image') {
        const c = await createImageClip(f); c.fileId = storeFile(f); clips.push(c); lastSel = { kind: 'clip', id: c.id };
      } else if (kind === 'video') {
        let vf = f;
        if (settings.optimizeVideos) {
          const opt = await optimizeVideoFile(f, f.name).catch(() => null);
          if (opt) vf = opt;
        }
        const c = await createVideoClip(vf.name, URL.createObjectURL(vf)); c.fileId = storeFile(vf); clips.push(c); lastSel = { kind: 'clip', id: c.id };
      } else if (kind === 'audio') {
        const m = await createMusic(f.name, URL.createObjectURL(f)); m.fileId = storeFile(f); music.push(m); lastSel = { kind: 'music', id: m.id };
      } else {
        toast(`Tipo di file non riconosciuto: ${f.name}`); await sleep(1500); continue;
      }
      added++;
      refresh();
    } catch (err) {
      console.error(err);
      toast(`Impossibile aprire "${f.name}": ${err.message}`, 5000);
      await sleep(1500);
    } finally {
      loadingCount--;
    }
  }
  if (added) {
    toast(`${added} file aggiunt${added === 1 ? 'o' : 'i'}`);
    if (lastSel) select(lastSel);
  }
}

async function cloneClip(c) {
  if (c.type === 'image') return { ...c, id: uid++ };
  const n = await createVideoClip(c.name, c.url, c.thumb);
  Object.assign(n, { in: c.in, out: c.out, muted: c.muted, volume: c.volume, transition: c.transition, fit: c.fit, fileId: c.fileId });
  return n;
}

function disposeMedia(item) {
  if (!item.el) return;
  item.el.pause();
  try { item.audio.src.disconnect(); item.audio.gain.disconnect(); } catch { /* ignore */ }
  item.el.remove();
}

/* =========================================================
 * Salvataggio automatico del progetto (IndexedDB del browser)
 * - "files":   copia di foto, video e musica importati
 * - "project": impostazioni, ordine e regolazioni delle clip
 * Tutto resta sul computer: niente viene inviato su internet.
 * ======================================================= */
let dbPromise = null;
function openDB() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open('editor-video', 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore('files');
        req.result.createObjectStore('project');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}
// Esegue un'operazione su un archivio e restituisce il risultato a operazione conclusa
async function idb(store, mode, fn) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const req = fn(tx.objectStore(store));
    tx.oncomplete = () => resolve(req ? req.result : undefined);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

const newId = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const pendingFiles = new Map(); // fileId -> scrittura in corso
let storageWarned = false, persistAsked = false;

function setSaveState(txt) {
  const el = $('#saveState');
  if (!el || DESKTOP) return;
  el.textContent = txt.replace(/^[✓⚠]\s*/, '');
  el.dataset.state = /^⚠/.test(txt) ? 'err' : /^✓/.test(txt) ? 'ok' : 'busy';
}

// Salva una copia del file e restituisce subito il suo identificativo
function storeFile(file) {
  if (!persistAsked) { persistAsked = true; navigator.storage?.persist?.().catch(() => {}); }
  const id = newId();
  setSaveState('Salvataggio…');
  const p = idb('files', 'readwrite', st => st.put({ blob: file, name: file.name, type: file.type }, id))
    .catch(err => {
      console.warn('Impossibile salvare il file', file.name, err);
      if (!storageWarned) {
        storageWarned = true;
        toast('Spazio del browser insufficiente: alcuni file non verranno ripristinati se ricarichi la pagina', 8000);
      }
    })
    .finally(() => { pendingFiles.delete(id); scheduleSave(false); });
  pendingFiles.set(id, p);
  return id;
}

function serializeProject() {
  return {
    version: 1,
    settings: { ...settings },
    pps,
    t: player.t,
    clips: clips.filter(c => c.fileId).map(c => c.type === 'image'
      ? { type: 'image', fileId: c.fileId, name: c.name, duration: c.duration, transition: c.transition, anim: c.anim, fit: c.fit }
      : { type: 'video', fileId: c.fileId, name: c.name, in: c.in, out: c.out, muted: c.muted, volume: c.volume, transition: c.transition, fit: c.fit }),
    music: music.filter(m => m.fileId).map(m => ({
      fileId: m.fileId, name: m.name, start: m.start, in: m.in, out: m.out, volume: m.volume, fadeIn: m.fadeIn, fadeOut: m.fadeOut,
    })),
  };
}

let saveTimer = 0, restoring = false;
function scheduleSave(changed = true) {
  if (restoring || !window.indexedDB) return;
  if (changed) markDirty();
  clearTimeout(saveTimer);
  setSaveState('Salvataggio…');
  saveTimer = setTimeout(saveProject, 400);
}

async function saveProject() {
  clearTimeout(saveTimer);
  saveTimer = 0;
  try {
    const data = serializeProject();
    await idb('project', 'readwrite', st => st.put(data, 'current'));
    // elimina le copie dei file non più usati nel progetto
    const used = new Set([...data.clips, ...data.music].map(x => x.fileId));
    const keys = await idb('files', 'readonly', st => st.getAllKeys());
    const unused = keys.filter(k => !used.has(k) && !pendingFiles.has(k));
    if (unused.length) await idb('files', 'readwrite', st => { unused.forEach(k => st.delete(k)); return null; });
    if (!saveTimer) setSaveState(pendingFiles.size ? 'Salvataggio…' : '✓ Progetto salvato');
  } catch (err) {
    console.warn('Salvataggio non riuscito', err);
    setSaveState('⚠ Non salvato');
  }
}

// Carica clip e musica descritte in "data"; getFile(item) restituisce il File
// da usare, afterLoad(obj, item, file) permette di completare l'oggetto creato
async function loadItems(data, getFile, afterLoad, label) {
  let missing = 0, n = 0;
  const tot = data.clips.length + data.music.length;
  const load = async item => {
    toast(`${label}… ${++n}/${tot}`, 60000);
    const file = await getFile(item).catch(() => null);
    if (!file) missing++;
    return file;
  };
  for (const sc of data.clips) {
    try {
      const file = await load(sc);
      if (!file) continue;
      const c = sc.type === 'image' ? await createImageClip(file) : await createVideoClip(file.name, URL.createObjectURL(file));
      const { type, media, ...saved } = sc;
      Object.assign(c, saved);
      if (c.type === 'video') { c.in = clamp(c.in, 0, c.srcDuration); c.out = clamp(c.out, c.in + 0.1, c.srcDuration); }
      afterLoad?.(c, sc, file);
      clips.push(c);
      refresh();
    } catch (err) { console.warn(err); missing++; }
  }
  for (const sm of data.music) {
    try {
      const file = await load(sm);
      if (!file) continue;
      const m = await createMusic(file.name, URL.createObjectURL(file));
      const { media, ...saved } = sm;
      Object.assign(m, saved);
      m.in = clamp(m.in, 0, m.srcDuration); m.out = clamp(m.out, m.in + 0.1, m.srcDuration);
      afterLoad?.(m, sm, file);
      music.push(m);
    } catch (err) { console.warn(err); missing++; }
  }
  return missing;
}

async function restoreProject() {
  if (!window.indexedDB) return;
  let data;
  try { data = await idb('project', 'readonly', st => st.get('current')); } catch { return; }
  if (DESKTOP) await restoreProjectMeta();
  if (!data) return;
  Object.assign(settings, data.settings || {});
  applyCanvasSize();
  if (data.pps) { pps = data.pps; $('#zoom').value = pps; paintRange($('#zoom')); }
  if (!data.clips.length && !data.music.length) { buildPanel(); return; }

  restoring = true;
  loadingCount++;
  $('#emptyState').hidden = true;
  ensureAudio();
  let missing = 0;
  try {
    missing = await loadItems(data, async item => {
      const rec = await idb('files', 'readonly', st => st.get(item.fileId)).catch(() => null);
      return rec ? new File([rec.blob], rec.name, { type: rec.type }) : null;
    }, null, 'Ripristino del progetto');
  } finally {
    restoring = false;
    loadingCount--;
  }
  const wasDirty = proj.dirty;
  refresh();
  proj.dirty = wasDirty; // il ripristino non è una modifica
  updateProjectUI();
  seek(data.t || 0);
  buildPanel();
  setSaveState('✓ Progetto salvato');
  toast(missing ? `Progetto ripristinato (${missing} file non trovati)` : 'Progetto ripristinato', 4000);
}

// Svuota il progetto corrente
function clearProject() {
  pause();
  for (const x of [...clips, ...music]) disposeMedia(x);
  clips.length = 0;
  music.length = 0;
  selected = null;
  player.t = 0;
}

async function newProject() {
  if (DESKTOP) {
    if (!(await confirmDiscard())) return;
  } else if ((clips.length || music.length) &&
      !confirm('Vuoi iniziare un nuovo progetto?\nIl progetto attuale verrà eliminato.')) return;
  clearProject();
  if (DESKTOP) resetProjectMeta();
  refresh();
  if (DESKTOP) { proj.dirty = false; updateProjectUI(); saveMeta(); }
  buildPanel();
  saveProject();
  toast('Nuovo progetto');
}

/* =========================================================
 * Progetti su file – solo versione Linux installata
 * Un progetto è una cartella:
 *   <Nome>/progetto.evideo   impostazioni, clip, musica (JSON)
 *   <Nome>/media/            copia di foto, video e musica usati
 * ======================================================= */
const PROJECT_FILE = 'progetto.evideo';
const proj = { name: '', dir: null, media: {}, dirty: false, change: 0, busy: false };

function resetProjectMeta() {
  Object.assign(proj, { name: '', dir: null, media: {}, dirty: false });
}
function markDirty() {
  if (!DESKTOP) return;
  proj.change++;
  if (!proj.dirty) { proj.dirty = true; updateProjectUI(); saveMetaSoon(); }
}
let metaTimer = 0;
function saveMetaSoon() { clearTimeout(metaTimer); metaTimer = setTimeout(saveMeta, 500); }
async function saveMeta() {
  if (!DESKTOP) return;
  try {
    await idb('project', 'readwrite', st => st.put({ name: proj.name, dir: proj.dir, media: proj.media, dirty: proj.dirty }, 'meta'));
  } catch (err) { console.warn('Impossibile salvare le informazioni del progetto', err); }
}
async function restoreProjectMeta() {
  try {
    const m = await idb('project', 'readonly', st => st.get('meta'));
    if (m) Object.assign(proj, { name: m.name || '', dir: m.dir || null, media: m.media || {}, dirty: !!m.dirty });
  } catch { /* niente */ }
  updateProjectUI();
}

function updateProjectUI() {
  if (!DESKTOP) return;
  const name = proj.name || 'Senza titolo';
  document.title = `${proj.dirty ? '• ' : ''}${name} – Editor Video`;
  const pn = $('#projName');
  pn.textContent = name;
  pn.title = proj.dir ? `Cartella del progetto: ${proj.dir.name}` : 'Progetto non ancora salvato su file';
  const st = $('#saveState');
  if (!clips.length && !music.length && !proj.dir) { st.textContent = ''; return; }
  if (!proj.dir) { st.textContent = 'Non salvato'; st.dataset.state = 'new'; }
  else if (proj.dirty) { st.textContent = 'Modifiche non salvate'; st.dataset.state = 'busy'; }
  else { st.textContent = 'Salvato'; st.dataset.state = 'ok'; }
}

// Nome valido per file e cartelle
function safeName(name) {
  return String(name).replace(/[\/\\:*?"<>|\x00-\x1f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
}
function uniqueName(name, taken) {
  const clean = safeName(name) || 'file';
  const dot = clean.lastIndexOf('.');
  const base = dot > 0 ? clean.slice(0, dot) : clean, ext = dot > 0 ? clean.slice(dot) : '';
  let n = clean, i = 2;
  while (taken.has(n)) n = `${base} (${i++})${ext}`;
  taken.add(n);
  return n;
}
async function hasFile(dir, name) {
  try { await dir.getFileHandle(name); return true; } catch { return false; }
}
async function ensurePermission(handle) {
  const o = { mode: 'readwrite' };
  try {
    if ((await handle.queryPermission(o)) === 'granted') return true;
    return (await handle.requestPermission(o)) === 'granted';
  } catch { return false; }
}

/* ---------- finestra di domanda (nome, conferme) ---------- */
function ask({ title, text = '', icon: ic = 'save', input = null, buttons }) {
  const dlg = $('#askDlg');
  $('#askTitle').textContent = title;
  $('#askText').innerHTML = text;
  $('#askIcon').setAttribute('href', `#i-${ic}`);
  const wrap = $('#askInputWrap'), inp = $('#askInput');
  wrap.hidden = !input;
  if (input) { $('#askLabel').textContent = input.label; inp.value = input.value || ''; }
  const box = $('#askBtns');
  box.innerHTML = '';
  return new Promise(resolve => {
    let done = false;
    const finish = v => { if (done) return; done = true; dlg.close(); resolve(v); };
    for (const b of buttons) {
      const el = document.createElement('button');
      el.className = `btn ${b.kind || ''}`;
      el.textContent = b.label;
      el.onclick = () => finish(b.value == null ? null : { button: b.value, input: inp.value });
      box.appendChild(el);
    }
    dlg.oncancel = e => { e.preventDefault(); finish(null); };
    inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); box.lastChild.click(); } };
    dlg.showModal();
    if (input) { inp.focus(); inp.select(); } else box.lastChild.focus();
  });
}

// Se ci sono modifiche non salvate chiede cosa fare. true = si può procedere
async function confirmDiscard() {
  if (!DESKTOP || !proj.dirty || (!clips.length && !music.length)) return true;
  const r = await ask({
    title: 'Salvare le modifiche?',
    text: `Il progetto <b>${esc(proj.name || 'Senza titolo')}</b> ha modifiche non salvate.`,
    buttons: [
      { label: 'Annulla', value: null, kind: 'ghost' },
      { label: 'Non salvare', value: 'discard', kind: 'ghost' },
      { label: 'Salva', value: 'save', kind: 'primary' },
    ],
  });
  if (!r) return false;
  if (r.button === 'save') return saveProjectFile();
  return true;
}

/* ---------- salvataggio ---------- */
async function saveProjectFile() {
  if (!clips.length && !music.length) { toast("Il progetto è vuoto: non c'è niente da salvare"); return false; }
  if (!proj.dir) return saveProjectAs();
  if (!(await ensurePermission(proj.dir))) { toast('Permesso negato: non posso scrivere nella cartella del progetto', 6000); return false; }
  try { await proj.dir.getFileHandle(PROJECT_FILE); } catch {
    // la cartella è stata spostata o cancellata
    toast('La cartella del progetto non è più raggiungibile: scegli dove salvarlo', 6000);
    return saveProjectAs();
  }
  return writeProject(proj.dir, proj.media, proj.name);
}

async function saveProjectAs() {
  if (!clips.length && !music.length) { toast("Il progetto è vuoto: non c'è niente da salvare"); return false; }
  const r = await ask({
    title: 'Salva progetto',
    text: 'Nella posizione che sceglierai verrà creata una cartella con questo nome, con dentro il progetto e una copia di foto, video e musica.',
    input: { label: 'Nome del progetto', value: proj.name || 'Il mio video' },
    buttons: [{ label: 'Annulla', value: null, kind: 'ghost' }, { label: 'Scegli dove salvare…', value: 'ok', kind: 'primary' }],
  });
  if (!r) return false;
  const name = safeName(r.input) || 'Il mio video';
  let parent;
  try {
    parent = await window.showDirectoryPicker({ id: 'editor-video-progetti', mode: 'readwrite', startIn: 'documents' });
  } catch (err) { if (err.name !== 'AbortError') toast('Impossibile aprire la scelta della cartella: ' + err.message, 6000); return false; }
  try {
    // se è stata scelta direttamente la cartella di un progetto, si usa quella
    const dir = (await hasFile(parent, PROJECT_FILE)) ? parent : await parent.getDirectoryHandle(name, { create: true });
    const same = proj.dir && await proj.dir.isSameEntry(dir).catch(() => false);
    if (!same && await hasFile(dir, PROJECT_FILE)) {
      const ok = await ask({
        title: 'Sostituire il progetto?', icon: 'folder-open',
        text: `La cartella <b>${esc(dir.name)}</b> contiene già un progetto. Vuoi sostituirlo con quello attuale?`,
        buttons: [{ label: 'Annulla', value: null, kind: 'ghost' }, { label: 'Sostituisci', value: 'ok', kind: 'danger' }],
      });
      if (!ok) return false;
    }
    let oldMedia = same ? proj.media : {};
    if (!same && await hasFile(dir, PROJECT_FILE)) {
      // sostituendo un altro progetto si eliminano i suoi file multimediali
      try {
        const old = JSON.parse(await (await (await dir.getFileHandle(PROJECT_FILE)).getFile()).text());
        oldMedia = Object.fromEntries([...(old.clips || []), ...(old.music || [])].map((x, i) => [`old-${i}`, x.media]));
      } catch { /* ignora */ }
    }
    return await writeProject(dir, oldMedia, name);
  } catch (err) {
    console.error(err);
    toast('Salvataggio non riuscito: ' + err.message, 8000);
    return false;
  }
}

async function writeProject(dir, oldMedia, name) {
  if (proj.busy) return false;
  proj.busy = true;
  const changeAtStart = proj.change;
  try {
    toast('Salvataggio del progetto…', 60000);
    await Promise.all(pendingFiles.values());
    const mediaDir = await dir.getDirectoryHandle('media', { create: true });
    const existing = new Set();
    for await (const [n, h] of mediaDir.entries()) if (h.kind === 'file') existing.add(n);
    const sameMedia = new Set(Object.values(oldMedia));
    const taken = new Set(existing);
    const media = {}, used = new Set();
    let missing = 0, copied = 0;
    const items = [...clips, ...music].filter(x => x.fileId);
    const toCopy = items.filter(x => !(oldMedia[x.fileId] && existing.has(oldMedia[x.fileId])));
    for (const it of items) {
      if (media[it.fileId]) continue;
      let fname = oldMedia[it.fileId];
      if (!fname || !existing.has(fname)) {
        const rec = await idb('files', 'readonly', st => st.get(it.fileId)).catch(() => null);
        if (!rec) { missing++; continue; }
        fname = uniqueName(rec.name, taken);
        copied++;
        toast(`Salvataggio: copia dei file ${copied}/${new Set(toCopy.map(x => x.fileId)).size} (${rec.name})…`, 60000);
        const w = await (await mediaDir.getFileHandle(fname, { create: true })).createWritable();
        await w.write(rec.blob);
        await w.close();
      }
      media[it.fileId] = fname;
      used.add(fname);
    }
    const data = serializeProject();
    const strip = list => list.map(({ fileId, ...rest }) => ({ ...rest, media: media[fileId] })).filter(x => x.media);
    const out = {
      app: 'editor-video', format: 1, name, saved: new Date().toISOString(),
      settings: data.settings, pps: data.pps, t: data.t,
      clips: strip(data.clips), music: strip(data.music),
    };
    const w = await (await dir.getFileHandle(PROJECT_FILE, { create: true })).createWritable();
    await w.write(JSON.stringify(out, null, 2));
    await w.close();
    // elimina i file multimediali del progetto che non servono più
    for (const f of sameMedia) if (f && !used.has(f) && existing.has(f)) await mediaDir.removeEntry(f).catch(() => {});

    proj.dir = dir;
    proj.name = name;
    proj.media = media;
    if (proj.change === changeAtStart) proj.dirty = false;
    await saveMeta();
    await addRecent(dir, name);
    updateProjectUI();
    toast(missing ? `Progetto "${name}" salvato, ma ${missing} file non erano disponibili` : `Progetto "${name}" salvato`, 4000);
    return true;
  } catch (err) {
    console.error(err);
    toast('Salvataggio non riuscito: ' + err.message, 8000);
    return false;
  } finally {
    proj.busy = false;
  }
}

/* ---------- apertura ---------- */
async function openProjectPicker() {
  if (!(await confirmDiscard())) return;
  let dir;
  try {
    dir = await window.showDirectoryPicker({ id: 'editor-video-progetti', mode: 'readwrite', startIn: 'documents' });
  } catch (err) { if (err.name !== 'AbortError') toast('Impossibile aprire la scelta della cartella: ' + err.message, 6000); return; }
  await openProjectDir(dir);
}

async function openProjectDir(dir) {
  let data;
  try {
    data = JSON.parse(await (await (await dir.getFileHandle(PROJECT_FILE)).getFile()).text());
    if (!Array.isArray(data.clips) || !Array.isArray(data.music)) throw new Error('formato');
  } catch {
    toast(`La cartella "${dir.name}" non contiene un progetto di Editor Video. Seleziona la cartella del progetto (quella con dentro il file ${PROJECT_FILE}).`, 9000);
    return false;
  }
  const mediaDir = await dir.getDirectoryHandle('media').catch(() => null);
  clearProject();
  resetProjectMeta();
  Object.assign(settings, data.settings || {});
  applyCanvasSize();
  if (data.pps) { pps = data.pps; $('#zoom').value = pps; paintRange($('#zoom')); }
  refresh();

  restoring = true;
  loadingCount++;
  $('#emptyState').hidden = true;
  ensureAudio();
  const media = {};
  let missing = 0;
  try {
    missing = await loadItems(data, async item => {
      if (!mediaDir || !item.media) return null;
      return (await mediaDir.getFileHandle(item.media)).getFile();
    }, (obj, item, file) => {
      obj.fileId = storeFile(file); // copia di lavoro per il ripristino automatico
      media[obj.fileId] = item.media;
    }, `Apertura di "${data.name || dir.name}"`);
  } finally {
    restoring = false;
    loadingCount--;
  }
  refresh();
  seek(data.t || 0);
  select(null);
  Object.assign(proj, { dir, name: data.name || dir.name, media, dirty: false });
  await saveMeta();
  await addRecent(dir, proj.name);
  updateProjectUI();
  toast(missing ? `Progetto aperto, ma ${missing} file non sono stati trovati nella cartella media` : `Progetto "${proj.name}" aperto`, 5000);
  return true;
}

/* ---------- progetti recenti ---------- */
async function getRecents() {
  try { return (await idb('project', 'readonly', st => st.get('recent'))) || []; } catch { return []; }
}
async function setRecents(list) {
  try { await idb('project', 'readwrite', st => st.put(list, 'recent')); } catch { /* ignora */ }
}
async function addRecent(dir, name) {
  const list = await getRecents();
  const out = [{ dir, name, when: Date.now() }];
  for (const r of list) {
    if (out.length >= 8) break;
    if (!(await r.dir.isSameEntry(dir).catch(() => false))) out.push(r);
  }
  await setRecents(out);
}
async function renderRecents() {
  const box = $('#recentList');
  const list = await getRecents();
  if (!list.length) { box.innerHTML = '<div class="menu-empty">Nessun progetto recente</div>'; return; }
  box.innerHTML = '';
  list.forEach((r, i) => {
    const b = document.createElement('button');
    b.className = 'menu-item';
    const when = new Date(r.when).toLocaleString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    b.innerHTML = `${icon('folder-open')}<span class="mi-text"><span>${esc(r.name)}</span><small>${when}</small></span>`;
    b.onclick = async () => {
      closeFileMenu();
      if (!(await confirmDiscard())) return;
      if (!(await ensurePermission(r.dir))) { toast('Permesso negato per la cartella del progetto', 6000); return; }
      const ok = await openProjectDir(r.dir);
      if (!ok) { const l = await getRecents(); l.splice(i, 1); await setRecents(l); }
    };
    box.appendChild(b);
  });
}

/* ---------- menu File ---------- */
function closeFileMenu() { $('#fileMenu').hidden = true; }
async function fileCommand(cmd) {
  closeFileMenu();
  if (proj.busy) return;
  if (cmd === 'new') return newProject();
  if (cmd === 'open') return openProjectPicker();
  if (cmd === 'save') return saveProjectFile();
  if (cmd === 'saveAs') return saveProjectAs();
}
function setupDesktop() {
  if (!DESKTOP) return;
  document.body.classList.add('desktop');
  $('#fileMenuWrap').hidden = false;
  $('#projName').hidden = false;
  $('#btnNew').hidden = true; // "Nuovo" è nel menu File
  $('#btnFile').onclick = async e => {
    e.stopPropagation();
    const m = $('#fileMenu');
    if (!m.hidden) return closeFileMenu();
    await renderRecents();
    m.hidden = false;
  };
  $('#fileMenu').addEventListener('click', e => {
    const b = e.target.closest('[data-cmd]');
    if (b) fileCommand(b.dataset.cmd);
  });
  document.addEventListener('click', e => { if (!e.target.closest('#fileMenuWrap')) closeFileMenu(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeFileMenu(); });
  updateProjectUI();
}

/* =========================================================
 * Calcolo della timeline
 * ======================================================= */
// Adattamento predefinito di una foto in base all'impostazione del progetto
function photoFitFor(w, h) {
  if (settings.photoFit === 'coverLandscape') return w > h ? 'cover' : 'contain';
  return settings.photoFit;
}

const clipDur = c => (c.type === 'image' ? c.duration : Math.max(0.1, c.out - c.in));

function relayout() {
  layout = [];
  let prev = null;
  for (const c of clips) {
    const dur = clipDur(c);
    let start = 0, tr = 0;
    if (prev) {
      tr = Math.max(0, Math.min(c.transition || 0, dur / 2, prev.dur / 2));
      start = prev.start + prev.dur - tr;
    }
    prev = { clip: c, start, dur, tr };
    layout.push(prev);
  }
  total = prev ? prev.start + prev.dur : 0;
}

function musicLen(m) {
  const len = Math.max(0.1, m.out - m.in);
  return total > 0 ? Math.max(0, Math.min(len, total - m.start)) : len;
}

/* =========================================================
 * Player
 * ======================================================= */
const player = { playing: false, t: 0, last: 0, raf: 0 };

function isActive(L, i, t) {
  const end = L.start + L.dur;
  return t >= L.start && (t < end || (i === layout.length - 1 && t <= end));
}

function syncMedia(hard) {
  const t = player.t;
  layout.forEach((L, i) => {
    const c = L.clip;
    if (c.type !== 'video') return;
    const v = c.el;
    const local = c.in + clamp(t - L.start, 0, L.dur);
    if (isActive(L, i, t) && t < total) {
      if (player.playing) {
        if (v.paused) { v.currentTime = local; v.play().catch(() => {}); }
        else if (Math.abs(v.currentTime - local) > 0.3) v.currentTime = local;
      } else {
        if (!v.paused) v.pause();
        if (hard || Math.abs(v.currentTime - local) > 0.03) v.currentTime = local;
      }
    } else {
      if (!v.paused) v.pause();
      if (isActive(L, i, t)) { // ultimo frame
        if (Math.abs(v.currentTime - local) > 0.03) v.currentTime = local;
      } else if (t < L.start && L.start - t < 3 && !v.seeking && Math.abs(v.currentTime - c.in) > 0.05) {
        v.currentTime = c.in; // pre-caricamento della clip successiva
      }
    }
  });

  for (const m of music) {
    const el = m.el;
    const len = musicLen(m);
    const active = player.playing && t >= m.start && t < m.start + len;
    const local = m.in + (t - m.start);
    if (active) {
      if (el.paused) { el.currentTime = local; el.play().catch(() => {}); }
      else if (Math.abs(el.currentTime - local) > 0.3) el.currentTime = local;
    } else {
      if (!el.paused) el.pause();
      if (t < m.start && m.start - t < 3 && !el.seeking && Math.abs(el.currentTime - m.in) > 0.05) el.currentTime = m.in;
    }
  }
}

function drawSource(src, sw, sh, fit, kb, rot = 0) {
  const W = canvas.width, H = canvas.height;
  const k = fit === 'cover' ? Math.max(W / sw, H / sh) : Math.min(W / sw, H / sh);
  const dw = sw * k * kb.s, dh = sh * k * kb.s;
  // posizione centrata + spostamento, limitata così da non uscire dallo schermo
  // (o, se la foto è più grande dello schermo, da non mostrare bordi vuoti)
  const fitPos = (avail, size, d) => {
    const pos = (avail - size) / 2 + d * avail;
    return avail >= size ? clamp(pos, 0, avail - size) : clamp(pos, avail - size, 0);
  };
  const x = fitPos(W, dw, kb.dx), y = fitPos(H, dh, kb.dy);
  if (!rot) { g.drawImage(src, x, y, dw, dh); return; }
  // fotogrammi decodificati di video girati (es. telefono in verticale)
  const side = rot === 90 || rot === 270;
  g.save();
  g.translate(x + dw / 2, y + dh / 2);
  g.rotate(rot * Math.PI / 180);
  const fw = side ? dh : dw, fh = side ? dw : dh;
  g.drawImage(src, -fw / 2, -fh / 2, fw, fh);
  g.restore();
}

// Calcola zoom/posizione della foto al punto p (0..1) dell'animazione
function photoMotion(c, p) {
  const a = ANIMATIONS[c.anim] || ANIMATIONS.none;
  const k = settings.animStrength;
  const sOf = v => 1 - (1 - v.s) * k;
  let s = lerp(sOf(a.from), sOf(a.to), p);
  const dx = lerp(a.from.dx, a.to.dx, p) * k, dy = lerp(a.from.dy, a.to.dy, p) * k;
  // "Riempi solo le orizzontali", foto verticali:
  // - ferme o che scivolano di lato: tutta l'altezza (niente bordi sopra/sotto)
  // - zoom: l'avvicinamento parte da tutta altezza e si ingrandisce,
  //   l'allontanamento arriva a tutta altezza
  const portraitFill = settings.photoFit === 'coverLandscape' && c.fit === 'contain' && c.h > c.w;
  const isZoom = a.from.s !== a.to.s;
  const sideOnly = !isZoom && !a.from.dy && !a.to.dy;
  if (portraitFill && sideOnly) s = 1;
  else if (portraitFill && isZoom) s /= Math.min(sOf(a.from), sOf(a.to));
  else if (c.fit === 'cover') {
    // in modalità "riempi" lo zoom parte da 1 per non lasciare bordi vuoti,
    // più un piccolo margine che lascia spazio allo scivolamento
    const maxOff = Math.max(Math.abs(a.from.dx), Math.abs(a.to.dx), Math.abs(a.from.dy), Math.abs(a.to.dy)) * k;
    s = s / Math.min(sOf(a.from), sOf(a.to)) * (1 + 2 * maxOff);
  }
  return { s, dx, dy };
}

function render() {
  const t = player.t;
  const W = canvas.width, H = canvas.height;
  g.globalAlpha = 1;
  g.fillStyle = '#000';
  g.fillRect(0, 0, W, H);


  layout.forEach((L, i) => {
    const c = L.clip;
    const active = isActive(L, i, t);
    // audio della clip video (con dissolvenza incrociata)
    if (c.type === 'video') {
      let gv = 0;
      if (active && !c.muted) {
        const aIn = L.tr > 0 ? clamp((t - L.start) / L.tr, 0, 1) : 1;
        const next = layout[i + 1];
        const aOut = next && next.tr > 0 && t > next.start ? clamp(1 - (t - next.start) / next.tr, 0, 1) : 1;
        gv = c.volume * aIn * aOut;
      }
      setGain(c.audio.gain, gv);
    }
    if (!active) return;

    const alpha = L.tr > 0 ? clamp((t - L.start) / L.tr, 0, 1) : 1;
    g.globalAlpha = alpha;
    g.fillStyle = '#000';
    g.fillRect(0, 0, W, H);
    if (c.type === 'image') {
      let p = clamp((t - L.start) / L.dur, 0, 1);
      if (settings.smoothAnim) p = easeInOut(p);
      drawSource(c.src, c.w, c.h, c.fit, photoMotion(c, p));
    } else {
      const ef = exportFrames.get(c.id);
      let drawn = false;
      if (ef && ef.frame) {
        try {
          const side = ef.rot === 90 || ef.rot === 270;
          const fw = ef.frame.displayWidth, fh = ef.frame.displayHeight;
          drawSource(ef.frame, side ? fh : fw, side ? fw : fh, c.fit, { s: 1, dx: 0, dy: 0 }, ef.rot);
          drawn = true;
        } catch { exportFrames.delete(c.id); } // fotogramma non più valido
      }
      if (drawn) { /* già disegnato */ } else if (c.el.readyState >= 2) {
        drawSource(c.el, c.el.videoWidth, c.el.videoHeight, c.fit, { s: 1, dx: 0, dy: 0 });
      }
    }
  });
  g.globalAlpha = 1;

  // dissolvenza globale da/verso nero
  let fade = 1;
  if (total > 0) {
    const fl = Math.min(1, total / 4);
    if (settings.fadeFromBlack) fade = Math.min(fade, clamp(t / fl, 0, 1));
    if (settings.fadeToBlack) fade = Math.min(fade, clamp((total - t) / fl, 0, 1));
  }
  if (fade < 1) {
    g.fillStyle = `rgba(0,0,0,${1 - fade})`;
    g.fillRect(0, 0, W, H);
  }

  // musica: volume + dissolvenze
  for (const m of music) {
    const len = musicLen(m);
    let e = 0;
    if (t >= m.start && t < m.start + len) {
      e = m.volume;
      if (m.fadeIn > 0) e *= clamp((t - m.start) / m.fadeIn, 0, 1);
      if (m.fadeOut > 0) e *= clamp((m.start + len - t) / m.fadeOut, 0, 1);
    }
    setGain(m.audio.gain, e);
  }
  if (master) setGain(master, fade);

  updateTimeUI();
}

let renderQueued = false;
function requestRender() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; if (!player.playing) render(); });
}

function tick(now) {
  if (!player.playing) return;
  const dt = Math.min(0.25, (now - player.last) / 1000);
  player.last = now;
  player.t += dt;
  if (player.t >= total) {
    player.t = total;
    render();
    stopPlayback();
    if (exp.running) finishExport();
    return;
  }
  syncMedia(false);
  render();
  if (exp.running) {
    $('#expProgress').value = total ? player.t / total : 0;
    $('#expStatus').textContent = `Registrazione… ${fmtTime(player.t)} / ${fmtTime(total)}`;
  }
  player.raf = requestAnimationFrame(tick);
}

function play() {
  if (!clips.length) { toast('Aggiungi prima qualche foto o video'); return; }
  ensureAudio();
  actx.resume();
  if (player.t >= total - 0.01) player.t = 0;
  player.playing = true;
  player.last = performance.now();
  syncMedia(true);
  $('#btnPlay').innerHTML = icon('pause');
  player.raf = requestAnimationFrame(tick);
}
function stopPlayback() {
  player.playing = false;
  cancelAnimationFrame(player.raf);
  for (const c of clips) if (c.el && !c.el.paused) c.el.pause();
  for (const m of music) if (!m.el.paused) m.el.pause();
  for (const m of music) setGain(m.audio.gain, 0);
  for (const c of clips) if (c.audio) setGain(c.audio.gain, 0);
  $('#btnPlay').innerHTML = icon('play');
}
function pause() {
  stopPlayback();
  syncMedia(true);
  requestRender();
}
function togglePlay() { player.playing ? pause() : play(); }
function seek(t) {
  player.t = clamp(t, 0, total);
  syncMedia(!player.playing);
  if (!player.playing) requestRender();
  updateTimeUI();
}

function updateTimeUI() {
  $('#timeLabel').textContent = `${fmtTime(player.t)} / ${fmtTime(total)}`;
  const sb = $('#seekBar');
  if (!seekDragging) sb.value = total ? Math.round(player.t / total * 1000) : 0;
  paintRange(sb);
  const x = player.t * pps;
  $('#playhead').style.transform = `translateX(${x}px)`;
  if (player.playing) {
    const sc = $('#tlScroll');
    if (x < sc.scrollLeft || x > sc.scrollLeft + sc.clientWidth - 40) sc.scrollLeft = Math.max(0, x - 60);
  }
}

/* =========================================================
 * Dimensioni del video
 * ======================================================= */
function updateOutInfo() {
  const el = $('#outInfo');
  if (el) el.textContent = `${canvas.width}×${canvas.height} · ${settings.fps} fps`;
}
function applyCanvasSize() {
  const q = settings.quality;
  let W, H;
  switch (settings.aspect) {
    case '9:16': W = q; H = q * 16 / 9; break;
    case '1:1': W = H = q; break;
    case '4:3': H = q; W = q * 4 / 3; break;
    default: H = q; W = q * 16 / 9;
  }
  canvas.width = even(W);
  canvas.height = even(H);
  updateOutInfo();
  requestRender();
}

/* =========================================================
 * Timeline (interfaccia)
 * ======================================================= */
function renderTimeline() {
  const musicEnd = music.reduce((m, x) => Math.max(m, x.start + (x.out - x.in)), 0);
  const span = Math.max(total, musicEnd, 10) + 5;
  const inner = $('#tlInner');
  inner.style.width = `${span * pps}px`;

  // righello
  const ruler = $('#ruler');
  const step = pps >= 80 ? 1 : pps >= 30 ? 2 : pps >= 15 ? 5 : 10;
  let html = '';
  for (let s = 0; s <= span; s += step) {
    html += `<div class="tick" style="left:${s * pps}px">${fmtTime(s).replace(/\.\d$/, '')}</div>`;
    if (step >= 2) html += `<div class="tick minor" style="left:${(s + step / 2) * pps}px"></div>`;
  }
  ruler.innerHTML = html;

  // traccia video
  const tv = $('#trackVideo');
  tv.innerHTML = '';
  layout.forEach((L, i) => {
    const c = L.clip;
    const d = document.createElement('div');
    d.className = `clip ${c.type}` + (isSel('clip', c.id) ? ' selected' : '');
    d.style.left = `${L.start * pps}px`;
    d.style.width = `${Math.max(4, L.dur * pps)}px`;
    d.style.zIndex = i + 1;
    d.style.backgroundImage = `url(${c.thumb})`;
    d.draggable = true;
    d.dataset.id = c.id;
    const badge = c.type === 'image' ? icon('image') : icon('film') + (c.muted ? icon('volume-x', 'warn') : '');
    d.innerHTML =
      (L.tr > 0 ? `<div class="trans" style="width:${L.tr * pps}px" title="Dissolvenza ${L.tr.toFixed(1)} s"></div>` : '') +
      `<span class="badge">${badge}</span>` +
      `<span class="label">${esc(c.name)} · ${L.dur.toFixed(1)}s</span>`;
    d.title = `${c.name}\n${L.dur.toFixed(1)} s`;
    d.addEventListener('click', e => {
      e.stopPropagation();
      select({ kind: 'clip', id: c.id });
      if (player.t < L.start || player.t > L.start + L.dur) seek(L.start + L.tr);
    });
    d.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/x-clip', String(c.id));
      e.dataTransfer.effectAllowed = 'move';
      d.classList.add('dragging');
    });
    d.addEventListener('dragend', () => { d.classList.remove('dragging'); $('#dropMarker').hidden = true; });
    tv.appendChild(d);
  });

  // traccia musica
  const tm = $('#trackMusic');
  tm.innerHTML = '';
  for (const m of music) {
    const d = document.createElement('div');
    d.className = 'clip music' + (isSel('music', m.id) ? ' selected' : '');
    const len = m.out - m.in;
    d.style.left = `${m.start * pps}px`;
    d.style.width = `${Math.max(4, len * pps)}px`;
    d.innerHTML = `<span class="label">${icon('music')} ${esc(m.name)} · ${len.toFixed(1)}s</span>`;
    d.title = 'Trascina per spostare la traccia nel tempo';
    attachMusicDrag(d, m);
    tm.appendChild(d);
  }
  // stato vuoto e riepilogo
  $('#emptyState').hidden = clips.length > 0 || loadingCount > 0;
  $('#tlStats').textContent = clips.length || music.length
    ? `${clips.length} clip · ${music.length} ${music.length === 1 ? 'traccia' : 'tracce'} · ${fmtTime(total)}`
    : '';
  updateTimeUI();
}

function dropIndexAt(x) {
  const t = x / pps;
  let idx = layout.length;
  for (let i = 0; i < layout.length; i++) {
    if (t < layout[i].start + layout[i].dur / 2) { idx = i; break; }
  }
  return idx;
}

function setupTimelineEvents() {
  const tv = $('#trackVideo');
  const marker = $('#dropMarker');
  tv.addEventListener('dragover', e => {
    if (!e.dataTransfer.types.includes('text/x-clip')) return;
    e.preventDefault();
    const x = e.clientX - tv.getBoundingClientRect().left;
    const idx = dropIndexAt(x);
    const pos = idx < layout.length ? layout[idx].start : total;
    marker.style.left = `${pos * pps}px`;
    marker.hidden = false;
  });
  tv.addEventListener('dragleave', () => { marker.hidden = true; });
  tv.addEventListener('drop', e => {
    const id = Number(e.dataTransfer.getData('text/x-clip'));
    if (!id) return;
    e.preventDefault();
    marker.hidden = true;
    const from = clips.findIndex(c => c.id === id);
    let to = dropIndexAt(e.clientX - tv.getBoundingClientRect().left);
    if (from < 0) return;
    if (to > from) to--;
    const [c] = clips.splice(from, 1);
    clips.splice(to, 0, c);
    refresh();
  });

  // click/trascinamento sul righello o su area vuota = sposta il cursore
  const scrubArea = [$('#ruler'), tv, $('#trackMusic')];
  for (const el of scrubArea) {
    el.addEventListener('pointerdown', e => {
      if (e.target.closest('.clip')) return;
      if (el !== $('#ruler')) select(null);
      const rect = $('#tlInner').getBoundingClientRect();
      const move = ev => seek((ev.clientX - rect.left) / pps);
      move(e);
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    });
  }
}

function attachMusicDrag(d, m) {
  d.addEventListener('pointerdown', e => {
    e.preventDefault();
    const x0 = e.clientX, s0 = m.start;
    let moved = false;
    d.setPointerCapture(e.pointerId);
    const move = ev => {
      const dx = ev.clientX - x0;
      if (Math.abs(dx) > 3) moved = true;
      if (!moved) return;
      m.start = Math.max(0, Math.round((s0 + dx / pps) * 10) / 10);
      d.style.left = `${m.start * pps}px`;
    };
    const up = () => {
      d.removeEventListener('pointermove', move);
      d.removeEventListener('pointerup', up);
      if (moved) { refresh(); if (isSel('music', m.id)) buildPanel(); }
      else select({ kind: 'music', id: m.id });
    };
    d.addEventListener('pointermove', move);
    d.addEventListener('pointerup', up);
  });
}

/* =========================================================
 * Selezione e pannello proprietà
 * ======================================================= */
const isSel = (kind, id) => selected && selected.kind === kind && selected.id === id;
function selectedItem() {
  if (!selected) return null;
  const list = selected.kind === 'clip' ? clips : music;
  return list.find(x => x.id === selected.id) || null;
}
function select(sel) {
  selected = sel;
  renderTimeline();
  buildPanel();
}

function refresh() {
  relayout();
  if (player.t > total) player.t = total;
  renderTimeline();
  seek(player.t);
  scheduleSave();
}

const panel = $('#panel');

function rangeField(label, k, val, min, max, step, unit = 's') {
  return `<div class="field">
    <div class="row"><span>${label}</span><output data-o="${k}" data-u="${unit}"></output></div>
    <input type="range" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${val}">
  </div>`;
}
function selectField(label, k, options, val) {
  const opts = Object.entries(options).map(([v, l]) => `<option value="${v}"${String(v) === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('');
  return `<label class="field"><span>${label}</span><select data-k="${k}">${opts}</select></label>`;
}
function checkField(label, k, val) {
  return `<label class="check"><input type="checkbox" data-k="${k}"${val ? ' checked' : ''}><span>${label}</span></label>`;
}
function fmtOut(v, unit) {
  if (unit === '%') return `${Math.round(v * 100)}%`;
  if (unit === 't') return fmtTime(v);
  if (unit === 'x') return `${Number(v).toFixed(2)}×`;
  return `${Number(v).toFixed(1)} s`;
}
function syncPanel(obj) {
  panel.querySelectorAll('output[data-o]').forEach(o => { o.textContent = fmtOut(obj[o.dataset.o], o.dataset.u); });
  panel.querySelectorAll('[data-k]').forEach(inp => {
    const v = obj[inp.dataset.k];
    if (inp.type === 'checkbox') inp.checked = !!v;
    else if (String(inp.value) !== String(v)) inp.value = v;
    if (inp.type === 'range') paintRange(inp);
  });
}
// Intestazione e riquadri del pannello
function panelHead({ ic, kind = '', title, sub, thumb }) {
  return `<div class="ph">
    ${thumb ? `<img class="ph-thumb" src="${thumb}" alt="">` : ''}
    <div class="ph-title"><div class="ph-icon ${kind}">${icon(ic)}</div>
      <div><h3>${title}</h3><div class="sub" title="${esc(sub)}">${esc(sub)}</div></div></div>
  </div>`;
}
const group = (title, body) => `<section class="group">${title ? `<h4>${title}</h4>` : ''}${body}</section>`;
const hint = txt => `<p class="hint-text">${txt}</p>`;
const actBtn = (act, ic, label, extra = '') => `<button class="btn small" data-act="${act}" ${extra}>${icon(ic)}${label}</button>`;
function bindPanel(obj, onChange) {
  panel.querySelectorAll('[data-k]').forEach(inp => {
    const k = inp.dataset.k;
    const ev = inp.type === 'checkbox' || inp.tagName === 'SELECT' ? 'change' : 'input';
    inp.addEventListener(ev, () => {
      let v;
      if (inp.type === 'checkbox') v = inp.checked;
      else if (inp.type === 'range' || inp.type === 'number') v = parseFloat(inp.value);
      else v = inp.value;
      if (typeof v === 'number' && !isFinite(v)) return;
      if (/^\d+$/.test(v)) v = Number(v);
      obj[k] = v;
      onChange(k, v);
      syncPanel(obj);
    });
  });
  panel.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => actions[b.dataset.act]?.()));
  syncPanel(obj);
}

function clipLayout(c) { return layout.find(L => L.clip === c); }

function buildPanel() {
  const item = selectedItem();
  if (!item) return buildProjectPanel();

  if (selected.kind === 'music') {
    const m = item;
    const maxStart = Math.max(Math.ceil(total), Math.ceil(m.start) + 1, 1);
    panel.innerHTML = `
      ${panelHead({ ic: 'music', kind: 'music', title: 'Traccia musicale', sub: `${m.name} · ${fmtTime(m.srcDuration)}` })}
      ${group('Posizione', `
        ${rangeField('Inizia nel video al secondo', 'start', m.start, 0, maxStart, 0.1, 't')}
        <div class="btnrow grid">
          ${actBtn('musicToStart', 'skip-start', "All'inizio")}
          ${actBtn('musicToCursor', 'cursor', 'Dal cursore')}
        </div>`)}
      ${group('Taglio della traccia', `
        ${rangeField('Parti dal punto', 'in', m.in, 0, m.srcDuration, 0.1, 't')}
        ${rangeField('Fermati al punto', 'out', m.out, 0, m.srcDuration, 0.1, 't')}
        ${hint('La musica viene tagliata automaticamente alla fine del video.')}`)}
      ${group('Volume e dissolvenze', `
        ${rangeField('Volume', 'volume', m.volume, 0, 1.5, 0.01, '%')}
        ${rangeField('Dissolvenza in entrata', 'fadeIn', m.fadeIn, 0, 10, 0.1)}
        ${rangeField('Dissolvenza in uscita', 'fadeOut', m.fadeOut, 0, 10, 0.1)}`)}
      <div class="panel-actions"><button class="btn danger" data-act="remove">${icon('trash')}Elimina traccia</button></div>`;
    bindPanel(m, k => {
      if (k === 'in') m.in = Math.min(m.in, m.out - 0.5);
      if (k === 'out') m.out = Math.max(m.out, m.in + 0.5);
      m.in = clamp(m.in, 0, m.srcDuration); m.out = clamp(m.out, 0, m.srcDuration);
      refresh();
    });
    return;
  }

  const c = item;
  const idx = clips.indexOf(c);
  const transition = idx > 0
    ? rangeField('Dissolvenza dalla clip precedente', 'transition', c.transition, 0, 3, 0.1)
    : hint("È la prima clip: la dissolvenza dal nero iniziale si regola nelle impostazioni del <b>Progetto</b>.");
  const fit = selectField('Adattamento allo schermo', 'fit', { contain: 'Mostra intera (bordi neri se servono)', cover: 'Riempi lo schermo (taglia i bordi)' }, c.fit);
  const arrange = group('Disposizione', `
    <div class="btnrow grid">
      ${actBtn('moveLeft', 'arrow-left', 'Sposta prima', idx === 0 ? 'disabled' : '')}
      ${actBtn('moveRight', 'arrow-right', 'Sposta dopo', idx === clips.length - 1 ? 'disabled' : '')}
    </div>
    <div class="btnrow grid">
      ${actBtn('duplicate', 'copy', 'Duplica')}
      <button class="btn small danger" data-act="remove">${icon('trash')}Elimina</button>
    </div>`);

  if (c.type === 'image') {
    const animOpts = Object.fromEntries(Object.entries(ANIMATIONS).map(([k, a]) => [k, a.label]));
    panel.innerHTML = `
      ${panelHead({ ic: 'image', kind: 'photo', title: 'Foto', sub: `${c.name} · ${c.w}×${c.h}`, thumb: c.thumb })}
      ${group('Tempo', `
        ${rangeField('Durata sullo schermo', 'duration', c.duration, 0.5, 30, 0.1)}
        ${transition}`)}
      ${group('Aspetto e movimento', `
        ${selectField('Animazione', 'anim', animOpts, c.anim)}
        ${fit}`)}
      ${group('Applica a tutte le foto', `
        ${hint('Copia le impostazioni di questa foto su tutte le altre.')}
        <div class="btnrow grid">
          ${actBtn('allDuration', 'clock', 'Durata', 'title="Dai a tutte le foto la durata di questa"')}
          ${actBtn('allTransition', 'wand', 'Dissolvenza', 'title="Dai a tutte le clip la dissolvenza di questa"')}
          ${actBtn('allAnim', 'copy', 'Animazione', 'title="Dai a tutte le foto l\'animazione di questa"')}
          ${actBtn('allRandom', 'shuffle', 'Casuali', 'title="Assegna animazioni casuali a tutte le foto"')}
        </div>`)}
      ${arrange}`;
  } else {
    panel.innerHTML = `
      ${panelHead({ ic: 'film', kind: 'video', title: 'Video', sub: `${c.name} · ${c.w}×${c.h} · ${fmtTime(c.srcDuration)}`, thumb: c.thumb })}
      ${isHeavySize(c.w, c.h) ? group('Video pesante', `
        ${hint(`È un video <b>${sizeLabel(c.w, c.h)}</b>: rallenta anteprima ed esportazione. Convertendolo in Full HD la qualità del video finale non cambia.`)}
        <div class="btnrow">${actBtn('optimize', 'wand', 'Ottimizza (converti in Full HD)', 'style="flex:1;justify-content:center"')}</div>`) : ''}
      ${group('Taglio', `
        ${rangeField('Inizio', 'in', c.in, 0, c.srcDuration, 0.05, 't')}
        ${rangeField('Fine', 'out', c.out, 0, c.srcDuration, 0.05, 't')}
        ${hint(`Durata nel video: <b id="vidLen">${(c.out - c.in).toFixed(1)} s</b>`)}
        <div class="btnrow grid">
          ${actBtn('setIn', 'mark-in', 'Inizio qui')}
          ${actBtn('setOut', 'mark-out', 'Fine qui')}
        </div>
        <div class="btnrow">${actBtn('split', 'scissors', 'Dividi al cursore', 'style="flex:1;justify-content:center"')}</div>`)}
      ${group('Audio', `
        ${checkField('Rimuovi audio del video', 'muted', c.muted)}
        ${rangeField('Volume', 'volume', c.volume, 0, 1.5, 0.01, '%')}`)}
      ${group('Transizione e aspetto', `
        ${transition}
        ${fit}`)}
      ${arrange}`;
  }

  bindPanel(c, k => {
    if (c.type === 'video') {
      if (k === 'in') c.in = clamp(Math.min(c.in, c.out - 0.2), 0, c.srcDuration);
      if (k === 'out') c.out = clamp(Math.max(c.out, c.in + 0.2), 0, c.srcDuration);
      const len = $('#vidLen'); if (len) len.textContent = `${(c.out - c.in).toFixed(1)} s`;
      const vol = panel.querySelector('[data-k=volume]'); if (vol) vol.disabled = c.muted;
    }
    refresh();
    const L = clipLayout(c);
    if (!L || player.playing) return;
    if (k === 'in' || k === 'duration' || k === 'anim' || k === 'transition') seek(L.start + (k === 'anim' ? 0 : Math.min(L.tr, L.dur)));
    if (k === 'out') seek(L.start + L.dur - 0.04);
  });
  if (c.type === 'video') panel.querySelector('[data-k=volume]').disabled = c.muted;
}

function buildProjectPanel() {
  const animOpts = { random: 'Casuale', ...Object.fromEntries(Object.entries(ANIMATIONS).map(([k, a]) => [k, a.label])) };
  const nPhotos = clips.filter(c => c.type === 'image').length;
  const nVideos = clips.length - nPhotos;
  panel.innerHTML = `
    ${panelHead({ ic: 'sliders', title: 'Progetto', sub: 'Impostazioni generali del video' })}
    <div class="stats">
      <div class="stat"><b>${nPhotos}</b><span>foto</span></div>
      <div class="stat"><b>${nVideos}</b><span>video</span></div>
      <div class="stat"><b>${music.length}</b><span>musica</span></div>
      <div class="stat"><b>${fmtTime(total).replace(/\.\d$/, '')}</b><span>durata</span></div>
    </div>
    ${group('Formato video', `
      ${selectField('Formato', 'aspect', { '16:9': 'Orizzontale 16:9 (YouTube, TV)', '9:16': 'Verticale 9:16 (Storie, Reels, TikTok)', '1:1': 'Quadrato 1:1', '4:3': 'Classico 4:3' }, settings.aspect)}
      ${selectField('Risoluzione', 'quality', { 480: '480p (leggero)', 720: '720p HD', 1080: '1080p Full HD' }, settings.quality)}
      ${selectField('Fotogrammi al secondo', 'fps', { 25: '25', 30: '30', 60: '60' }, settings.fps)}`)}
    ${group('Video', `
      ${checkField('Converti in Full HD i video più grandi quando li aggiungi (consigliato)', 'optimizeVideos', settings.optimizeVideos)}
      ${hint('Video 4K e simili diventano molto più veloci da montare ed esportare; il video finale è comunque al massimo 1080p.')}
      ${(() => { const n = clips.filter(x => x.type === 'video' && isHeavySize(x.w, x.h)).length;
        return n ? `<div class="btnrow">${actBtn('optimizeAll', 'wand', `Ottimizza i video già inseriti (${n})`, 'style="flex:1;justify-content:center"')}</div>` : ''; })()}`)}
    ${group('Dissolvenze', `
      ${checkField('Inizia con dissolvenza dal nero', 'fadeFromBlack', settings.fadeFromBlack)}
      ${checkField('Termina con dissolvenza verso il nero', 'fadeToBlack', settings.fadeToBlack)}`)}
    ${group('Foto', `
      ${selectField('Adattamento allo schermo', 'photoFit', {
        contain: 'Mostra tutte le foto intere (bordi neri se servono)',
        coverLandscape: 'Riempi lo schermo solo con le foto orizzontali (le verticali restano intere)',
        cover: 'Riempi lo schermo con tutte le foto (taglia i bordi)',
      }, settings.photoFit)}
      ${hint('Vale per tutte le foto, anche quelle aggiunte dopo. Puoi comunque cambiarla per una singola foto.')}
      ${rangeField('Intensità del movimento', 'animStrength', settings.animStrength, 0.25, 2.5, 0.05, 'x')}
      ${hint('1× = leggero (consigliato). Più basso = quasi fermo.')}
      ${checkField('Movimento morbido (parte e si ferma dolcemente)', 'smoothAnim', settings.smoothAnim)}`)}
    ${group('Valori per le nuove foto', `
      ${rangeField('Durata foto', 'photoDuration', settings.photoDuration, 0.5, 30, 0.1)}
      ${rangeField('Dissolvenza tra le clip', 'transition', settings.transition, 0, 3, 0.1)}
      ${selectField('Animazione', 'defaultAnim', animOpts, settings.defaultAnim)}
      <div class="btnrow">${actBtn('applyDefaultsAll', 'wand', 'Applica a tutte le clip', 'style="flex:1;justify-content:center"')}</div>`)}
    ${group('Scorciatoie da tastiera', `
      <div class="kbd-list">
        <kbd>Spazio</kbd><span>Play / pausa</span>
        <kbd>← →</kbd><span>Sposta il cursore</span>
        <kbd>Shift + ← →</kbd><span>Clip precedente / successiva</span>
        <kbd>Canc</kbd><span>Elimina la clip selezionata</span>
        <kbd>Rotellina</kbd><span>Scorre la timeline</span>
        <kbd>Ctrl + rotellina</kbd><span>Zoom della timeline</span>
        ${DESKTOP ? `<kbd>Ctrl + S</kbd><span>Salva il progetto</span>
        <kbd>Ctrl + Shift + S</kbd><span>Salva con nome</span>
        <kbd>Ctrl + O</kbd><span>Apri un progetto</span>` : ''}
      </div>`)}`;
  bindPanel(settings, k => {
    scheduleSave();
    if (k === 'aspect' || k === 'quality') applyCanvasSize();
    if (k === 'fps') updateOutInfo();
    if (k === 'photoFit') {
      clips.forEach(x => { if (x.type === 'image') x.fit = photoFitFor(x.w, x.h); });
      refresh();
      toast({
        contain: 'Tutte le foto ora sono mostrate intere',
        coverLandscape: 'Le foto orizzontali riempiono lo schermo, le verticali restano intere',
        cover: 'Tutte le foto ora riempiono lo schermo',
      }[settings.photoFit]);
    }
    requestRender();
  });
}

/* =========================================================
 * Azioni dei pulsanti
 * ======================================================= */
function cursorLocal(c) {
  const L = clipLayout(c);
  if (!L || player.t < L.start || player.t > L.start + L.dur) return null;
  return c.in + (player.t - L.start);
}

const actions = {
  remove() {
    const item = selectedItem();
    if (!item) return;
    if (selected.kind === 'clip') clips.splice(clips.indexOf(item), 1);
    else music.splice(music.indexOf(item), 1);
    disposeMedia(item);
    selected = null;
    refresh();
    buildPanel();
  },
  moveLeft() { move(-1); },
  moveRight() { move(1); },
  async duplicate() {
    const c = selectedItem();
    const n = await cloneClip(c);
    clips.splice(clips.indexOf(c) + 1, 0, n);
    refresh();
    select({ kind: 'clip', id: n.id });
  },
  setIn() {
    const c = selectedItem(); const l = cursorLocal(c);
    if (l == null) return toast('Porta il cursore rosso sopra questa clip');
    if (l >= c.out - 0.2) return toast("L'inizio deve essere prima della fine");
    const L = clipLayout(c);
    c.in = l; refresh(); buildPanel(); seek(L.start);
  },
  setOut() {
    const c = selectedItem(); const l = cursorLocal(c);
    if (l == null) return toast('Porta il cursore rosso sopra questa clip');
    if (l <= c.in + 0.2) return toast('La fine deve essere dopo l\'inizio');
    c.out = l; refresh(); buildPanel();
  },
  async split() {
    const c = selectedItem(); const l = cursorLocal(c);
    if (l == null) return toast('Porta il cursore rosso sopra questa clip');
    if (l <= c.in + 0.2 || l >= c.out - 0.2) return toast('Cursore troppo vicino al bordo della clip');
    const n = await cloneClip(c);
    c.out = l; n.in = l; n.transition = 0;
    clips.splice(clips.indexOf(c) + 1, 0, n);
    refresh();
    select({ kind: 'clip', id: n.id });
    toast('Clip divisa in due: ora puoi eliminare o spostare una parte');
  },
  allDuration() { const c = selectedItem(); clips.forEach(x => { if (x.type === 'image') x.duration = c.duration; }); refresh(); toast('Durata applicata a tutte le foto'); },
  allAnim() { const c = selectedItem(); clips.forEach(x => { if (x.type === 'image') x.anim = c.anim; }); refresh(); toast('Animazione applicata a tutte le foto'); },
  allRandom() { clips.forEach(x => { if (x.type === 'image') x.anim = randomAnim(); }); refresh(); buildPanel(); toast('Animazioni casuali assegnate'); },
  allTransition() { const c = selectedItem(); clips.forEach(x => { x.transition = c.transition; }); refresh(); toast('Dissolvenza applicata a tutte le clip'); },
  applyDefaultsAll() {
    clips.forEach(x => {
      x.transition = settings.transition;
      if (x.type === 'image') {
        x.duration = settings.photoDuration;
        x.anim = settings.defaultAnim === 'random' ? randomAnim() : settings.defaultAnim;
      }
    });
    refresh(); buildPanel(); toast('Impostazioni applicate a tutte le clip');
  },
  optimize() {
    const c = selectedItem();
    if (c && c.type === 'video') optimizeExistingClips(clips.filter(x => x.type === 'video' && (x.fileId ? x.fileId === c.fileId : x.url === c.url)));
  },
  optimizeAll() {
    const list = clips.filter(x => x.type === 'video' && isHeavySize(x.w, x.h));
    if (list.length) optimizeExistingClips(list);
  },
  musicToStart() { const m = selectedItem(); m.start = 0; refresh(); buildPanel(); },
  musicToCursor() { const m = selectedItem(); m.start = Math.round(player.t * 10) / 10; refresh(); buildPanel(); },
};

// Shift + frecce: va all'inizio della clip successiva o precedente
// (il punto in cui la clip è già del tutto visibile, dopo la dissolvenza)
function jumpClip(dir) {
  if (!layout.length) return;
  const starts = layout.map((L, i) => (i === 0 ? 0 : L.start + L.tr));
  const t = player.t;
  let idx = -1;
  if (dir > 0) idx = starts.findIndex(p => p > t + 0.001);
  else for (let i = starts.length - 1; i >= 0; i--) if (starts[i] < t - 0.001) { idx = i; break; }
  if (idx < 0) { if (dir > 0) seek(total); return; }
  seek(starts[idx]);
  select({ kind: 'clip', id: layout[idx].clip.id });
  const sc = $('#tlScroll'), x = starts[idx] * pps;
  if (x < sc.scrollLeft || x > sc.scrollLeft + sc.clientWidth - 40) sc.scrollLeft = Math.max(0, x - 60);
}

function move(dir) {
  const c = selectedItem();
  const i = clips.indexOf(c), j = i + dir;
  if (j < 0 || j >= clips.length) return;
  [clips[i], clips[j]] = [clips[j], clips[i]];
  refresh();
  buildPanel();
}

/* =========================================================
 * Esportazione
 * ======================================================= */
const exp = { mode: 'fast', gen: 0, stage: '', progressAt: 0, watchdog: 0, cleanup: null, running: false, rec: null, chunks: [], canceled: false, mime: '', url: null };

const FORMATS = [
  ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'MP4 (H.264 + AAC) – consigliato', 'mp4'],
  ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'MP4 (H.264 + AAC)', 'mp4'],
  ['video/mp4;codecs=avc1,mp4a.40.2', 'MP4 (H.264 + AAC)', 'mp4'],
  ['video/mp4', 'MP4', 'mp4'],
  ['video/webm;codecs=vp9,opus', 'WebM (VP9 + Opus)', 'webm'],
  ['video/webm;codecs=vp8,opus', 'WebM (VP8 + Opus)', 'webm'],
  ['video/webm', 'WebM', 'webm'],
];
function supportedFormats() {
  if (!window.MediaRecorder) return [];
  const seen = new Set();
  return FORMATS.filter(([m, label]) => {
    if (!MediaRecorder.isTypeSupported(m) || seen.has(label)) return false;
    seen.add(label);
    return true;
  });
}

function openExport() {
  if (!clips.length) return toast('Il progetto è vuoto: aggiungi foto o video');
  if (loadingCount > 0) return toast('Attendi la fine del caricamento dei file');
  pause();
  const fmts = supportedFormats();
  const fast = fastSupported();
  if (!fmts.length && !fast) return toast('Questo browser non supporta l\'esportazione video. Usa Chrome o Edge aggiornati.', 6000);
  $('#expFormat').innerHTML = fmts.map(([m, l]) => `<option value="${m}">${esc(l)}</option>`).join('');
  const modeSel = $('#expMode');
  modeSel.querySelector('[value=fast]').disabled = !fast;
  modeSel.querySelector('[value=realtime]').disabled = !fmts.length;
  modeSel.value = fast ? 'fast' : 'realtime';
  updateExportMode();
  $('#expInfo').textContent = `Risoluzione ${canvas.width}×${canvas.height} · ${settings.fps} fps · durata ${fmtTime(total)}`;
  showExportStep('setup');
  $('#exportDlg').showModal();
}
function updateExportMode() {
  const rt = $('#expMode').value === 'realtime';
  $('#expFormatField').hidden = !rt;
  $('#expNoteRT').hidden = !rt;
  $('#expNoteFast').hidden = rt;
}
function showExportStep(step) {
  $('#exportSetup').hidden = step !== 'setup';
  $('#exportRun').hidden = step !== 'run';
  $('#exportDone').hidden = step !== 'done';
}

async function waitVideosReady(t) {
  const deadline = performance.now() + 5000;
  for (const [i, L] of layout.entries()) {
    if (L.clip.type !== 'video' || !isActive(L, i, t)) continue;
    const v = L.clip.el;
    while ((v.seeking || v.readyState < 2) && performance.now() < deadline) await sleep(30);
  }
}

async function startExport() {
  exp.mode = $('#expMode').value;
  if (exp.mode !== 'fast') return realtimeExport();
  // Chrome/Edge: il video viene scritto direttamente nel file scelto mentre
  // viene creato, senza doverlo tenere tutto in memoria
  exp.fileHandle = null;
  if (window.showSaveFilePicker) {
    try {
      exp.fileHandle = await window.showSaveFilePicker({
        suggestedName: exportFileName('mp4'),
        types: [{ description: 'Video MP4', accept: { 'video/mp4': ['.mp4'] } }],
      });
    } catch (err) {
      if (err.name === 'AbortError') return; // finestra "Salva" annullata: si resta qui
      console.warn('Salvataggio diretto non disponibile, uso il download', err);
      exp.fileHandle = null;
    }
  }
  return fastExport();
}

// Raccoglie il file MP4 a pezzi (nessun unico blocco di memoria enorme).
// Gestisce anche le riscritture di zone già scritte (es. intestazioni).
class ChunkStore {
  constructor() { this.parts = []; this.starts = []; this.end = 0; }
  append(data) { this.parts.push(data); this.starts.push(this.end); this.end += data.length; }
  write(data, pos) {
    data = data.slice(); // copia: il muxer può riutilizzare il suo buffer
    if (pos > this.end) this.append(new Uint8Array(pos - this.end));
    if (pos === this.end) { this.append(data); return; }
    // riscrittura di una zona già scritta
    const stop = Math.min(pos + data.length, this.end);
    this.parts.forEach((p, i) => {
      const ps = this.starts[i];
      const a = Math.max(pos, ps), b = Math.min(stop, ps + p.length);
      if (a < b) p.set(data.subarray(a - pos, b - pos), a - ps);
    });
    if (pos + data.length > this.end) this.append(data.slice(this.end - pos));
  }
  toBlob() { return new Blob(this.parts, { type: 'video/mp4' }); }
}

function exportFileName(ext) {
  if (DESKTOP && proj.name) return `${safeName(proj.name)}.${ext}`;
  const d = new Date();
  const p2 = n => String(n).padStart(2, '0');
  return `video_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.${ext}`;
}

function deliverFile(blob, ext, extra = '') {
  if (exp.url) URL.revokeObjectURL(exp.url);
  exp.url = URL.createObjectURL(blob);
  const name = exportFileName(ext);
  const a = $('#expDownload');
  a.hidden = false;
  a.href = exp.url;
  a.download = name;
  $('#expResult').textContent = `${name} · ${(blob.size / 1048576).toFixed(1)} MB${extra}`;
  showExportStep('done');
  a.click(); // download automatico
}

async function realtimeExport() {
  ensureAudio();
  await actx.resume();
  exp.mime = $('#expFormat').value;
  exp.canceled = false;
  exp.chunks = [];
  showExportStep('run');
  $('#expProgress').value = 0;
  $('#expStatus').textContent = 'Preparazione…';
  select(null);

  seek(0);
  await waitVideosReady(0);
  render();
  await sleep(300);

  const vTrack = canvas.captureStream(settings.fps).getVideoTracks();
  const aTrack = exportDest.stream.getAudioTracks();
  const stream = new MediaStream([...vTrack, ...aTrack]);
  let rec;
  try {
    rec = new MediaRecorder(stream, {
      mimeType: exp.mime,
      videoBitsPerSecond: Number($('#expBitrate').value),
      audioBitsPerSecond: 192000,
    });
  } catch (err) {
    console.error(err);
    toast('Impossibile avviare la registrazione: ' + err.message, 6000);
    $('#exportDlg').close();
    return;
  }
  exp.rec = rec;
  rec.ondataavailable = e => { if (e.data && e.data.size) exp.chunks.push(e.data); };
  rec.onstop = () => {
    stream.getVideoTracks().forEach(t => t.stop());
    exp.running = false;
    if (exp.canceled) return;
    const ext = FORMATS.find(f => f[0] === exp.mime)?.[2] || 'webm';
    deliverFile(new Blob(exp.chunks, { type: exp.mime.split(';')[0] }), ext);
  };
  exp.running = true;
  rec.start(1000);
  play();
}

async function finishExport() {
  await sleep(250); // ultimo fotogramma
  if (exp.rec && exp.rec.state !== 'inactive') exp.rec.stop();
}

/* ---------------------------------------------------------
 * Esportazione veloce: i fotogrammi vengono calcolati uno per
 * uno e codificati con WebCodecs, l'audio è mixato "offline".
 * Non serve aspettare la durata reale del video.
 * ------------------------------------------------------- */
const AUDIO_RATE = 48000;
const fastSupported = () =>
  'VideoEncoder' in window && 'VideoFrame' in window && 'OfflineAudioContext' in window && !!window.Mp4Muxer;

async function pickVideoConfig(W, H, fps, bitrate, accel = 'no-preference') {
  // livello H.264 minimo adatto a risoluzione e fps (livelli troppo alti
  // possono mettere in difficoltà alcuni codificatori hardware)
  const mbs = Math.ceil(W / 16) * Math.ceil(H / 16), mbps = mbs * fps;
  const level = mbs <= 3600 && mbps <= 108000 ? '1F'      // 3.1 (720p30)
    : mbs <= 8192 && mbps <= 245760 ? '28'                 // 4.0 (1080p30)
    : mbs <= 8704 && mbps <= 522240 ? '2A'                 // 4.2 (1080p60)
    : '33';                                                 // 5.1
  const codecs = [`avc1.6400${level}`, `avc1.4D00${level}`, `avc1.4200${level}`, 'avc1.640033', 'avc1.42003E'];
  for (const codec of codecs) {
    const cfg = { codec, width: W, height: H, bitrate, framerate: fps, hardwareAcceleration: accel, avc: { format: 'avc' } };
    try { if ((await VideoEncoder.isConfigSupported(cfg)).supported) return cfg; } catch { /* prova il prossimo */ }
  }
  return null;
}

async function pickAudioConfig() {
  if (!('AudioEncoder' in window)) return null;
  for (const [codec, mux] of [['mp4a.40.2', 'aac'], ['opus', 'opus']]) {
    const cfg = { codec, sampleRate: AUDIO_RATE, numberOfChannels: 2, bitrate: 192000 };
    try { if ((await AudioEncoder.isConfigSupported(cfg)).supported) return { cfg, mux }; } catch { /* prova il prossimo */ }
  }
  return null;
}

const audioCache = new Map(); // url -> AudioBuffer | null
async function decodeAudio(url) {
  if (audioCache.has(url)) return audioCache.get(url);
  let buf = null;
  try {
    const data = await (await fetch(url)).arrayBuffer();
    const dc = new OfflineAudioContext(2, 1, AUDIO_RATE);
    buf = await dc.decodeAudioData(data);
  } catch { buf = null; } // video senza audio
  audioCache.set(url, buf);
  return buf;
}

// Crea la colonna sonora completa (audio dei video + musica + dissolvenze)
async function renderAudioMix() {
  const oc = new OfflineAudioContext(2, Math.max(1, Math.ceil(total * AUDIO_RATE)), AUDIO_RATE);
  const mst = oc.createGain();
  mst.connect(oc.destination);
  const fl = Math.min(1, total / 4);
  mst.gain.setValueAtTime(settings.fadeFromBlack ? 0 : 1, 0);
  if (settings.fadeFromBlack) mst.gain.linearRampToValueAtTime(1, fl);
  if (settings.fadeToBlack) { mst.gain.setValueAtTime(1, total - fl); mst.gain.linearRampToValueAtTime(0, total); }

  for (const [i, L] of layout.entries()) {
    const c = L.clip;
    if (c.type !== 'video' || c.muted || c.volume <= 0) continue;
    const buf = await decodeAudio(c.url);
    if (!buf) continue;
    const src = oc.createBufferSource();
    src.buffer = buf;
    const gn = oc.createGain();
    src.connect(gn).connect(mst);
    const v = c.volume, a = L.start, b = L.start + L.dur, next = layout[i + 1];
    gn.gain.setValueAtTime(L.tr > 0 ? 0 : v, a);
    if (L.tr > 0) gn.gain.linearRampToValueAtTime(v, a + L.tr);
    if (next && next.tr > 0) { gn.gain.setValueAtTime(v, next.start); gn.gain.linearRampToValueAtTime(0, b); }
    src.start(a, c.in, L.dur);
  }

  for (const m of music) {
    const len = musicLen(m);
    if (len <= 0) continue;
    const buf = await decodeAudio(m.url);
    if (!buf) continue;
    const src = oc.createBufferSource();
    src.buffer = buf;
    const gn = oc.createGain();
    src.connect(gn).connect(mst);
    const v = m.volume, a = m.start, b = m.start + len;
    const fi = Math.min(m.fadeIn, len), fo = Math.min(m.fadeOut, len);
    gn.gain.setValueAtTime(fi > 0 ? 0 : v, a);
    if (fi > 0) gn.gain.linearRampToValueAtTime(v, a + fi);
    if (fo > 0) { gn.gain.setValueAtTime(v, Math.max(a + fi, b - fo)); gn.gain.linearRampToValueAtTime(0, b); }
    src.start(a, m.in, len);
  }
  return oc.startRendering();
}

// Codifica l'audio a pezzi, fino al secondo "untilSec"
function makeAudioFeeder(buffer, encoder) {
  const N = buffer.length, CH = 4096, SR = buffer.sampleRate;
  const L = buffer.getChannelData(0), R = buffer.getChannelData(buffer.numberOfChannels > 1 ? 1 : 0);
  let off = 0;
  return untilSec => {
    const end = Math.min(N, Math.ceil(untilSec * SR));
    while (off < end) {
      const n = Math.min(CH, N - off);
      const data = new Float32Array(n * 2);
      data.set(L.subarray(off, off + n), 0);
      data.set(R.subarray(off, off + n), n);
      const ad = new AudioData({
        format: 'f32-planar', sampleRate: SR, numberOfFrames: n,
        numberOfChannels: 2, timestamp: Math.round(off / SR * 1e6), data,
      });
      encoder.encode(ad);
      ad.close();
      off += n;
    }
  };
}

function seekExact(v, t) {
  return new Promise(resolve => {
    let done = false;
    const fin = () => { if (done) return; done = true; v.removeEventListener('seeked', fin); resolve(); };
    v.addEventListener('seeked', fin);
    v.currentTime = t;
    setTimeout(fin, 5000);
  });
}

/* ---------------------------------------------------------
 * Lettura veloce dei fotogrammi dei video (MP4/MOV) con
 * WebCodecs: il file viene decodificato in sequenza invece
 * di "saltare" a ogni fotogramma con il lettore video.
 * ------------------------------------------------------- */
const exportFrames = new Map(); // clip.id -> { frame, rot }

// Legge solo le parti del file che descrivono il contenuto (tutto tranne 'mdat')
async function readMp4Info(blob) {
  if (!window.MP4Box) return null;
  const file = MP4Box.createFile(false);
  let info = null, error = null, moov = null;
  file.onReady = i => { info = i; };
  file.onError = e => { error = e; };
  let pos = 0;
  while (pos + 8 <= blob.size && !info && !error) {
    const head = new DataView(await blob.slice(pos, pos + 16).arrayBuffer());
    let size = head.getUint32(0);
    const type = String.fromCharCode(head.getUint8(4), head.getUint8(5), head.getUint8(6), head.getUint8(7));
    if (size === 1) size = Number(head.getBigUint64(8));
    else if (size === 0) size = blob.size - pos;
    if (size < 8) break;
    // del blocco dati 'mdat' basta l'intestazione: il parser lo salta
    const len = type === 'mdat' ? (head.getUint32(0) === 1 ? 16 : 8) : size;
    if (len > 200 * 1048576) return null; // struttura anomala
    const buf = await blob.slice(pos, pos + len).arrayBuffer();
    if (type === 'moov') moov = buf.slice(0);
    buf.fileStart = pos;
    file.appendBuffer(buf);
    pos += size;
  }
  file.flush();
  if (!info) return null;
  return { file, info, moov };
}

function codecDescription(file, trackId) {
  const trak = file.getTrackById(trackId);
  for (const entry of trak.mdia.minf.stbl.stsd.entries) {
    const box = entry.avcC || entry.hvcC || entry.vpcC || entry.av1C;
    if (box) {
      const stream = new DataStream(undefined, 0, DataStream.BIG_ENDIAN);
      box.write(stream);
      return new Uint8Array(stream.buffer, 8); // senza l'intestazione del box
    }
  }
  return undefined;
}

class VideoFrameReader {
  static async open(clip) {
    if (!('VideoDecoder' in window)) return null;
    try {
      const blob = await (await fetch(clip.url)).blob();
      const parsed = await readMp4Info(blob);
      if (!parsed) return null;
      const track = parsed.info.videoTracks[0];
      if (!track) return null;
      const config = {
        codec: track.codec,
        codedWidth: track.video.width,
        codedHeight: track.video.height,
        description: codecDescription(parsed.file, track.id),
      };
      const sup = await VideoDecoder.isConfigSupported(config);
      if (!sup.supported) return null;
      const samples = parsed.file.getTrackSamplesInfo(track.id);
      if (!samples || !samples.length) return null;
      const m = track.matrix || [65536, 0, 0, 0, 65536, 0, 0, 0, 0x40000000];
      const rot = ((Math.round(Math.atan2(m[1], m[0]) * 180 / Math.PI / 90) * 90) % 360 + 360) % 360;
      return new VideoFrameReader(clip, blob, samples, config, rot);
    } catch (err) {
      console.warn('Lettura veloce non disponibile per', clip.name, err);
      return null;
    }
  }

  constructor(clip, blob, samples, config, rot) {
    this.blob = blob;
    this.rot = rot;
    this.frames = [];
    this.ended = false;
    this.error = null;
    const minCts = Math.min(...samples.slice(0, 64).map(s => s.cts));
    this.samples = samples.map(s => ({
      offset: s.offset, size: s.size, key: s.is_sync,
      t: (s.cts - minCts) / s.timescale,
      dur: s.duration / s.timescale,
    }));
    // parte dall'ultimo fotogramma chiave prima del punto di inizio
    let start = 0;
    for (let i = 0; i < this.samples.length; i++) {
      if (this.samples[i].key && this.samples[i].t <= clip.in + 1e-3) start = i;
    }
    this.next = start;
    this.limit = clip.out + 1;
    this.target = -Infinity;
    this.lastOutput = performance.now();
    this.decoder = new VideoDecoder({
      output: f => {
        this.lastOutput = performance.now();
        this.frames.push(f);
        this.frames.sort((a, b) => a.timestamp - b.timestamp);
        this.prune();
      },
      error: e => { this.error = e; },
    });
    this.decoder.configure(config);
  }

  // Chiude subito i fotogrammi già superati: alcune schede grafiche ne
  // possono tenere in memoria solo pochi, altrimenti la decodifica si ferma
  prune() {
    while (this.frames.length > 1 && this.frames[1].timestamp <= this.target) this.frames.shift().close();
  }

  ready() {
    const last = this.frames[this.frames.length - 1];
    return !!last && last.timestamp > this.target;
  }

  async feed() {
    const batch = [];
    while (batch.length < 4 && this.next < this.samples.length) {
      const s = this.samples[this.next];
      if (s.t > this.limit && s.key) break;
      batch.push(s);
      this.next++;
    }
    if (!batch.length) {
      if (!this.ended) {
        const ok = await Promise.race([this.decoder.flush().then(() => true), sleep(5000).then(() => false)]);
        if (!ok) throw new Error('stall');
        this.ended = true;
      }
      return;
    }
    const datas = await Promise.all(batch.map(s => this.blob.slice(s.offset, s.offset + s.size).arrayBuffer()));
    batch.forEach((s, i) => this.decoder.decode(new EncodedVideoChunk({
      type: s.key ? 'key' : 'delta',
      timestamp: Math.round(s.t * 1e6),
      duration: Math.round(s.dur * 1e6),
      data: datas[i],
    })));
    // attende che il decodificatore smaltisca, ma solo finché serve
    while (this.decoder.decodeQueueSize > 2 && !this.error && !this.ready()) {
      if (performance.now() - this.lastOutput > 5000) throw new Error('stall');
      await sleep(1);
    }
  }

  // Restituisce il fotogramma visibile al tempo t (secondi del file originale)
  async frameAt(t) {
    this.target = t * 1e6 + 500;
    this.prune();
    this.lastOutput = performance.now();
    while (!this.ended && !this.ready()) {
      if (this.error) throw this.error;
      await this.feed();
      this.prune();
    }
    this.prune();
    return this.frames[0] || null;
  }

  close() {
    for (const f of this.frames) f.close();
    this.frames = [];
    try { if (this.decoder.state !== 'closed') this.decoder.close(); } catch { /* ignore */ }
  }
}

const frameReaders = new Map(); // clip.id -> VideoFrameReader | null (null = usa il lettore video)
const finishedReaders = new Set();

async function prepareFramesAt(t, gen = exp.gen) {
  const seeks = [];
  for (const [i, L] of layout.entries()) {
    const c = L.clip;
    if (c.type !== 'video') continue;
    if (!isActive(L, i, t)) {
      if (t > L.start + L.dur && frameReaders.get(c.id)) {
        frameReaders.get(c.id).close();
        frameReaders.set(c.id, null);
        finishedReaders.add(c.id);
        exportFrames.delete(c.id);
      }
      continue;
    }
    const local = Math.min(c.in + clamp(t - L.start, 0, L.dur), c.srcDuration - 0.001);
    if (!frameReaders.has(c.id) && !finishedReaders.has(c.id)) {
      exp.stage = `apertura del video "${c.name}"`;
      const r = await withTimeout(VideoFrameReader.open(c), 10000).catch(() => null);
      if (exp.gen !== gen) { if (r) r.close(); return; }
      frameReaders.set(c.id, r);
    }
    exp.stage = `lettura del video "${c.name}"`;
    const reader = frameReaders.get(c.id);
    if (reader) {
      try {
        const frame = await withTimeout(reader.frameAt(local), 8000);
        if (exp.gen !== gen) return;
        exportFrames.set(c.id, { frame, rot: reader.rot });
        if (frame) continue;
      } catch (err) {
        if (exp.gen !== gen) return;
        // decodifica bloccata o in errore: si passa al lettore video per questa clip
        console.warn('Lettura veloce interrotta per', c.name, err);
        reader.close();
        frameReaders.set(c.id, null);
      }
      exportFrames.delete(c.id);
    }
    // metodo di riserva: posiziona il lettore video
    const v = c.el;
    if (!v.paused) v.pause();
    if (Math.abs(v.currentTime - local) < 1e-4 && !v.seeking && v.readyState >= 2) continue;
    seeks.push(seekExact(v, local));
  }
  if (seeks.length) exp.stage = 'posizionamento del lettore video';
  await Promise.all(seeks);
}

function closeFrameReaders() {
  for (const r of frameReaders.values()) if (r) r.close();
  frameReaders.clear();
  finishedReaders.clear();
  exportFrames.clear();
}

/* ---------------------------------------------------------
 * Ottimizzazione dei video pesanti (es. 4K) all'importazione.
 * Il video viene convertito una volta sola in Full HD: il file
 * esportato è al massimo 1080p, quindi la qualità finale non
 * cambia, ma anteprima ed esportazione diventano molto più leggere.
 * L'audio AAC viene copiato così com'è (nessuna perdita).
 * ------------------------------------------------------- */
const OPT_LONG = 1920, OPT_SHORT = 1080;
const isHeavySize = (w, h) => Math.max(w, h) > OPT_LONG || Math.min(w, h) > OPT_SHORT;
const sizeLabel = (w, h) => (Math.max(w, h) >= 3800 ? '4K' : Math.max(w, h) >= 2500 ? 'Quad HD' : 'alta risoluzione');

// Legge le caratteristiche del video (solo MP4/MOV) e decide se va ottimizzato
async function probeVideo(blob) {
  if (!('VideoDecoder' in window) || !('VideoEncoder' in window) || !window.Mp4Muxer) return null;
  const parsed = await readMp4Info(blob).catch(() => null);
  if (!parsed) return null;
  const track = parsed.info.videoTracks[0];
  if (!track) return null;
  const m = track.matrix || [65536, 0, 0, 0, 65536, 0, 0, 0, 0x40000000];
  const rot = ((Math.round(Math.atan2(m[1], m[0]) * 180 / Math.PI / 90) * 90) % 360 + 360) % 360;
  const cw = track.video.width, ch = track.video.height;
  const side = rot === 90 || rot === 270;
  const dw = side ? ch : cw, dh = side ? cw : ch;
  const k = Math.min(1, OPT_LONG / Math.max(dw, dh), OPT_SHORT / Math.min(dw, dh));
  const tw = Math.max(2, Math.round(dw * k / 2) * 2), th = Math.max(2, Math.round(dh * k / 2) * 2);
  const vconfig = { codec: track.codec, codedWidth: cw, codedHeight: ch, description: codecDescription(parsed.file, track.id) };
  try { if (!(await VideoDecoder.isConfigSupported(vconfig)).supported) return null; } catch { return null; }
  return { parsed, track, rot, dw, dh, tw, th, vconfig, heavy: isHeavySize(dw, dh) };
}

function audioSpecificConfig(file, trackId) {
  try {
    const entry = file.getTrackById(trackId).mdia.minf.stbl.stsd.entries[0];
    return entry.esds.esd.findDescriptor(4).findDescriptor(5).data;
  } catch { return null; }
}

// Nei .MOV la configurazione AAC sta dentro un box 'wave' che mp4box non legge:
// la si cerca direttamente nei byte del box 'moov' (box 'esds')
function findEsdsDsi(moov) {
  if (!moov) return null;
  const b = new Uint8Array(moov);
  for (let i = 4; i + 8 < b.length; i++) {
    if (b[i] !== 0x65 || b[i + 1] !== 0x73 || b[i + 2] !== 0x64 || b[i + 3] !== 0x73) continue; // 'esds'
    let p = i + 8; // tipo + versione/flag
    const readLen = () => { let n = 0; for (let k = 0; k < 4; k++) { const c = b[p++]; n = (n << 7) | (c & 0x7f); if (!(c & 0x80)) break; } return n; };
    if (b[p++] !== 0x03) continue;
    readLen();
    p += 2;
    const fl = b[p++];
    if (fl & 0x80) p += 2;
    if (fl & 0x40) p += b[p] + 1;
    if (fl & 0x20) p += 2;
    if (b[p++] !== 0x04) continue;
    readLen();
    p += 13;
    if (b[p++] !== 0x05) continue;
    const len = readLen();
    if (len > 0 && p + len <= b.length) return b.slice(p, p + len);
  }
  return null;
}

// Converte il video in Full HD; restituisce un Blob MP4 oppure null
async function transcodeVideo(blob, info, { onProgress, canceled }) {
  const { parsed, track, rot, tw, th, vconfig } = info;
  const vs = parsed.file.getTrackSamplesInfo(track.id);
  if (!vs || !vs.length) return null;
  const vMin = Math.min(...vs.slice(0, 64).map(x => x.cts));
  const durSec = Math.max(0.1, (Math.max(...vs.map(x => x.cts + x.duration)) - vMin) / vs[0].timescale);
  const fps = clamp(Math.round(vs.length / durSec), 1, 60);

  // audio: copia diretta se AAC; altri formati non sono gestiti (si usa l'originale)
  const atrack = parsed.info.audioTracks[0];
  let audio = null;
  if (atrack) {
    const dsi = audioSpecificConfig(parsed.file, atrack.id) || findEsdsDsi(parsed.moov);
    if (!/^mp4a/.test(atrack.codec) || !dsi) return null;
    const codec = /^mp4a\.40\.\d+$/.test(atrack.codec) ? atrack.codec : `mp4a.40.${(dsi[0] >> 3) || 2}`;
    const as = parsed.file.getTrackSamplesInfo(atrack.id) || [];
    const aMin = as.length ? Math.min(...as.slice(0, 16).map(x => x.cts)) : 0;
    audio = { track: atrack, codec, dsi, samples: as, aMin, next: 0, metaSent: false };
  }

  const bitrate = clamp(Math.round(tw * th * fps * 0.2), 4e6, 20e6);
  const ecfg = await pickVideoConfig(tw, th, fps, bitrate);
  if (!ecfg) return null;

  const store = new ChunkStore();
  const muxer = new Mp4Muxer.Muxer({
    target: new Mp4Muxer.StreamTarget({ onData: (d, pos) => store.write(d, pos), chunked: true }),
    video: { codec: 'avc', width: tw, height: th, frameRate: fps },
    audio: audio ? { codec: 'aac', numberOfChannels: audio.track.audio.channel_count, sampleRate: audio.track.audio.sample_rate } : undefined,
    fastStart: false,
    firstTimestampBehavior: 'offset',
  });

  const cvs = 'OffscreenCanvas' in window ? new OffscreenCanvas(tw, th) : Object.assign(document.createElement('canvas'), { width: tw, height: th });
  const cx = cvs.getContext('2d');
  cx.imageSmoothingQuality = 'high';

  let err = null, encoded = 0;
  const pending = [];
  const enc = new VideoEncoder({ output: (c, meta) => muxer.addVideoChunk(c, meta), error: e => { err = e; } });
  enc.configure(ecfg);
  const dec = new VideoDecoder({ output: f => pending.push(f), error: e => { err = e; } });
  dec.configure(vconfig);

  // copia l'audio fino al secondo "untilUs"
  const feedAudio = async untilUs => {
    if (!audio) return;
    const a = audio;
    while (a.next < a.samples.length) {
      const sm = a.samples[a.next];
      const t = Math.round((sm.cts - a.aMin) / sm.timescale * 1e6);
      if (t > untilUs) break;
      const data = await blob.slice(sm.offset, sm.offset + sm.size).arrayBuffer();
      const chunk = new EncodedAudioChunk({ type: 'key', timestamp: t, duration: Math.round(sm.duration / sm.timescale * 1e6), data });
      muxer.addAudioChunk(chunk, a.metaSent ? undefined : {
        decoderConfig: { codec: a.codec, sampleRate: a.track.audio.sample_rate, numberOfChannels: a.track.audio.channel_count, description: a.dsi },
      });
      a.metaSent = true;
      a.next++;
    }
  };

  const handleFrames = async () => {
    while (pending.length) {
      pending.sort((x, y) => x.timestamp - y.timestamp);
      const f = pending.shift();
      cx.fillStyle = '#000';
      cx.fillRect(0, 0, tw, th);
      if (rot) {
        const sideways = rot === 90 || rot === 270;
        cx.save();
        cx.translate(tw / 2, th / 2);
        cx.rotate(rot * Math.PI / 180);
        const fw = sideways ? th : tw, fh = sideways ? tw : th;
        cx.drawImage(f, -fw / 2, -fh / 2, fw, fh);
        cx.restore();
      } else {
        cx.drawImage(f, 0, 0, tw, th);
      }
      const out = new VideoFrame(cvs, { timestamp: f.timestamp, duration: f.duration || Math.round(1e6 / fps) });
      f.close();
      enc.encode(out, { keyFrame: encoded % fps === 0 });
      out.close();
      encoded++;
      await feedAudio(out.timestamp + 1e6);
      while (enc.encodeQueueSize > 4) { if (err) throw err; await sleep(1); }
    }
  };

  try {
    let i = 0;
    const t0 = performance.now();
    while (i < vs.length) {
      if (canceled()) return null;
      if (err) throw err;
      const batch = vs.slice(i, i + 6);
      i += batch.length;
      const datas = await Promise.all(batch.map(x => blob.slice(x.offset, x.offset + x.size).arrayBuffer()));
      batch.forEach((x, j) => dec.decode(new EncodedVideoChunk({
        type: x.is_sync ? 'key' : 'delta',
        timestamp: Math.round((x.cts - vMin) / x.timescale * 1e6),
        duration: Math.round(x.duration / x.timescale * 1e6),
        data: datas[j],
      })));
      while (dec.decodeQueueSize > 3 && !err) { await handleFrames(); await sleep(1); }
      await handleFrames();
      onProgress?.(encoded / vs.length, (performance.now() - t0) / 1000);
      await yieldUI();
    }
    await dec.flush();
    await handleFrames();
    await enc.flush();
    await feedAudio(Infinity);
    if (err) throw err;
    if (canceled()) return null;
    muxer.finalize();
    return store.toBlob();
  } finally {
    for (const f of pending) f.close();
    try { if (dec.state !== 'closed') dec.close(); } catch { /* ignore */ }
    try { if (enc.state !== 'closed') enc.close(); } catch { /* ignore */ }
  }
}

// Mostra la finestra di conversione; restituisce il nuovo File oppure null
async function optimizeVideoFile(blob, name, info = null) {
  info = info || await probeVideo(blob);
  if (!info || !info.heavy) return null;
  const dlg = $('#convDlg');
  let skip = false;
  $('#convSkip').onclick = () => { skip = true; $('#convStatus').textContent = 'Annullamento…'; };
  dlg.oncancel = e => e.preventDefault();
  $('#convInfo').textContent = `${name}`;
  $('#convText').innerHTML = `È un video <b>${sizeLabel(info.dw, info.dh)}</b> (${info.dw}×${info.dh}). Lo converto una volta sola in <b>${info.tw}×${info.th}</b>: anteprima ed esportazione saranno molto più veloci e la qualità del video finale non cambia.`;
  $('#convProgress').value = 0;
  $('#convStatus').textContent = 'Avvio…';
  dlg.showModal();
  let out = null;
  try {
    out = await transcodeVideo(blob, info, {
      canceled: () => skip,
      onProgress: (p, secs) => {
        $('#convProgress').value = p;
        const eta = p > 0.03 ? Math.round(secs / p * (1 - p)) : null;
        $('#convStatus').textContent = `Conversione… ${Math.round(p * 100)}%` + (eta != null ? ` · circa ${eta >= 60 ? `${Math.floor(eta / 60)} min ${eta % 60} s` : `${eta} s`} rimanenti` : '');
      },
    });
  } catch (err) {
    console.warn('Ottimizzazione non riuscita', err);
    out = null;
  }
  dlg.close();
  if (!out) {
    if (!skip) toast(`Non è stato possibile ottimizzare "${name}": uso il video originale`, 6000);
    return null;
  }
  const base = name.replace(/\.[^.]+$/, '');
  return new File([out], `${base}.mp4`, { type: 'video/mp4' });
}

// Ottimizza video già presenti nel progetto (mantiene tagli e impostazioni)
async function optimizeExistingClips(list) {
  const groups = new Map();
  for (const c of list) {
    const key = c.fileId || c.url;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(c);
  }
  pause();
  let done = 0;
  const selId = selected && selected.kind === 'clip' ? selected.id : null;
  let newSel = null;
  for (const group of groups.values()) {
    const c0 = group[0];
    let blob = null;
    if (c0.fileId) {
      await pendingFiles.get(c0.fileId);
      const rec = await idb('files', 'readonly', st => st.get(c0.fileId)).catch(() => null);
      if (rec) blob = rec.blob;
    }
    if (!blob) blob = await (await fetch(c0.url)).blob();
    const file = await optimizeVideoFile(blob, c0.name);
    if (!file) continue;
    const fid = storeFile(file);
    for (const c of group) {
      const idx = clips.indexOf(c);
      if (idx < 0) continue;
      const n = await createVideoClip(file.name, URL.createObjectURL(file), c.thumb);
      Object.assign(n, { in: c.in, out: c.out, muted: c.muted, volume: c.volume, transition: c.transition, fit: c.fit, fileId: fid });
      n.in = clamp(n.in, 0, n.srcDuration);
      n.out = clamp(n.out, n.in + 0.1, n.srcDuration);
      clips[idx] = n;
      disposeMedia(c);
      if (c.id === selId) newSel = n.id;
    }
    done++;
    refresh();
  }
  if (newSel) select({ kind: 'clip', id: newSel }); else buildPanel();
  if (done) toast(`${done} video ottimizzat${done === 1 ? 'o' : 'i'}`);
}

// Cede il controllo al browser senza i rallentamenti di setTimeout
// (canale unico e sempre referenziato: un canale creato al volo può essere
// eliminato dal browser prima di consegnare il messaggio, bloccando tutto)
const yieldChannel = new MessageChannel();
const yieldQueue = [];
yieldChannel.port1.onmessage = () => { const r = yieldQueue.shift(); if (r) r(); };
const yieldUI = () => new Promise(r => { yieldQueue.push(r); yieldChannel.port2.postMessage(0); });

class ExportStall extends Error {}

// Attende una promessa al massimo "ms" millisecondi
const withTimeout = (p, ms) => Promise.race([p, sleep(ms).then(() => { throw new ExportStall('timeout'); })]);

async function fastExport() {
  const status = txt => { $('#expStatus').textContent = txt; };
  const gen = ++exp.gen;
  exp.canceled = false;
  exp.running = true;
  exp.stage = 'preparazione';
  exp.progressAt = performance.now();
  showExportStep('run');
  $('#expProgress').value = 0;
  stopPlayback();
  select(null);

  // Sentinella: se l'esportazione veloce non avanza per 20 s viene
  // abbandonata e si passa da soli alla modalità in tempo reale
  clearInterval(exp.watchdog);
  exp.watchdog = setInterval(() => {
    if (exp.gen !== gen) { clearInterval(exp.watchdog); return; }
    if (performance.now() - exp.progressAt < 20000) return;
    clearInterval(exp.watchdog);
    const where = exp.stage;
    console.warn('Esportazione veloce bloccata durante:', where);
    abandonFastExport();
    if (!supportedFormats().length) {
      exp.running = false;
      $('#exportDlg').close();
      toast(`Esportazione bloccata (durante: ${where}).`, 10000);
      return;
    }
    toast(`La modalità veloce si è bloccata (durante: ${where}). Passo alla modalità in tempo reale.`, 10000);
    exp.mode = 'realtime';
    $('#expFormat').selectedIndex = 0;
    realtimeExport();
  }, 1000);

  try {
    let result;
    try {
      result = await fastExportAttempt('no-preference', status, gen);
    } catch (err) {
      if (!(err instanceof ExportStall) || exp.gen !== gen || exp.canceled) throw err;
      // il codificatore della scheda grafica si è bloccato: riprova via software
      console.warn('Codificatore bloccato, nuovo tentativo con codifica software');
      status('Nuovo tentativo con un metodo più compatibile…');
      $('#expProgress').value = 0;
      exp.progressAt = performance.now();
      result = await fastExportAttempt('prefer-software', status, gen);
    }
    if (exp.gen !== gen) return;
    clearInterval(exp.watchdog);
    exp.running = false;
    if (result.saved) showSavedFile(result.secs);
    else deliverFile(result.blob, 'mp4', ` · creato in ${result.secs.toFixed(0)} s`);
  } catch (err) {
    if (exp.gen !== gen) return; // abbandonata (interrotta o sostituita): niente da fare
    clearInterval(exp.watchdog);
    exp.running = false;
    $('#exportDlg').close();
    if (err.message === 'canceled') {
      toast('Esportazione interrotta');
    } else {
      console.error(err);
      const why = err instanceof ExportStall ? 'il codificatore video non risponde' : err.message;
      toast(`Esportazione veloce non riuscita (${why}). Prova la modalità "In tempo reale".`, 9000);
    }
  } finally {
    if (exp.gen === gen) { closeFrameReaders(); seek(0); }
  }
}

async function showSavedFile(secs) {
  let info = exp.fileHandle.name;
  try { info += ` · ${((await exp.fileHandle.getFile()).size / 1048576).toFixed(1)} MB`; } catch { /* ignore */ }
  $('#expResult').textContent = `Salvato come ${info} · creato in ${secs.toFixed(0)} s`;
  $('#expDownload').hidden = true;
  showExportStep('done');
}

// Abbandona subito l'esportazione veloce in corso, anche se è bloccata
function abandonFastExport() {
  exp.gen++;
  clearInterval(exp.watchdog);
  try { exp.cleanup?.(); } catch { /* ignore */ }
  exp.cleanup = null;
  closeFrameReaders();
}

async function fastExportAttempt(accel, status, gen) {
  const W = canvas.width, H = canvas.height, fps = settings.fps;
  let venc = null, aenc = null;
  const alive = () => { if (exp.gen !== gen || exp.canceled) throw new Error('canceled'); };
  exp.cleanup = () => {
    try { if (venc && venc.state !== 'closed') venc.close(); } catch { /* ignore */ }
    try { if (aenc && aenc.state !== 'closed') aenc.close(); } catch { /* ignore */ }
  };
  try {
    status('Preparazione…');
    exp.stage = 'scelta del codificatore video';
    const vcfg = await pickVideoConfig(W, H, fps, Number($('#expBitrate').value), accel);
    if (!vcfg) throw new Error('il browser non sa codificare video H.264');
    const acfg = await pickAudioConfig();

    alive();
    status('Preparazione audio…');
    exp.stage = 'preparazione audio';
    const hasAudio = music.length > 0 || clips.some(c => c.type === 'video' && !c.muted);
    const mix = acfg && hasAudio ? await renderAudioMix() : null;
    alive();
    exp.progressAt = performance.now();

    // destinazione: file su disco (Chrome/Edge) oppure memoria a pezzi
    let target, store = null, writable = null;
    if (exp.fileHandle) {
      writable = await exp.fileHandle.createWritable();
      target = new Mp4Muxer.FileSystemWritableFileStreamTarget(writable);
    } else {
      store = new ChunkStore();
      target = new Mp4Muxer.StreamTarget({ onData: (data, position) => store.write(data, position), chunked: true });
    }
    const prevCleanup = exp.cleanup;
    exp.cleanup = () => { prevCleanup?.(); if (writable) writable.abort().catch(() => {}); };
    const muxer = new Mp4Muxer.Muxer({
      target,
      video: { codec: 'avc', width: W, height: H, frameRate: fps },
      audio: mix ? { codec: acfg.mux, numberOfChannels: 2, sampleRate: AUDIO_RATE } : undefined,
      fastStart: false,
      firstTimestampBehavior: 'offset',
    });
    let encErr = null;
    venc = new VideoEncoder({ output: (ch, meta) => muxer.addVideoChunk(ch, meta), error: e => { encErr = e; } });
    venc.configure(vcfg);
    let feedAudio = null;
    if (mix) {
      aenc = new AudioEncoder({ output: (ch, meta) => muxer.addAudioChunk(ch, meta), error: e => { encErr = e; } });
      aenc.configure(acfg.cfg);
      feedAudio = makeAudioFeeder(mix, aenc);
    }

    // attende che i codificatori smaltiscano la coda, con controllo anti-blocco
    const drain = async () => {
      const since = performance.now();
      while (venc.encodeQueueSize > 4 || (aenc && aenc.encodeQueueSize > 16)) {
        if (encErr) throw encErr;
        alive();
        if (performance.now() - since > 8000) throw new ExportStall('encoder');
        await sleep(2);
      }
    };

    const N = Math.max(1, Math.round(total * fps));
    const t0 = performance.now();
    for (let i = 0; i < N; i++) {
      alive();
      if (encErr) throw encErr;
      exp.progressAt = performance.now();
      player.t = Math.min(i / fps, total);
      await prepareFramesAt(player.t, gen);
      alive();
      exp.stage = 'disegno del fotogramma';
      render();
      const frame = new VideoFrame(canvas, { timestamp: Math.round(i * 1e6 / fps), duration: Math.round(1e6 / fps) });
      venc.encode(frame, { keyFrame: i % (fps * 2) === 0 });
      frame.close();
      exp.stage = 'codifica audio';
      if (feedAudio) feedAudio((i + 1) / fps + 0.5);
      exp.stage = 'codifica video';
      await drain();
      if (i % 5 === 0) {
        const done = (i + 1) / N;
        const elapsed = (performance.now() - t0) / 1000;
        const speed = elapsed > 0.5 ? ` · ${((i + 1) / fps / elapsed).toFixed(1)}× più veloce del tempo reale` : '';
        $('#expProgress').value = done;
        status(`Creazione video… ${Math.round(done * 100)}%${speed}`);
        exp.stage = 'attesa del browser';
        await yieldUI();
      }
    }
    if (feedAudio) feedAudio(Infinity);
    status('Finalizzazione…');
    exp.stage = 'finalizzazione';
    exp.progressAt = performance.now() + 20000; // la finalizzazione ha già i suoi tempi massimi
    await withTimeout(venc.flush(), 20000);
    if (aenc) await withTimeout(aenc.flush(), 20000);
    if (encErr) throw encErr;
    alive();
    muxer.finalize();
    const secs = (performance.now() - t0) / 1000;
    if (writable) {
      await writable.close(); // attende che tutto sia scritto sul disco
      writable = null;
      return { saved: true, secs };
    }
    return { blob: store.toBlob(), secs };
  } finally {
    if (exp.gen === gen) {
      exp.cleanup?.();
      exp.cleanup = null;
      closeFrameReaders();
    }
  }
}

function abortExport() {
  exp.canceled = true;
  if (exp.mode === 'fast') {
    // chiude subito, senza aspettare che l'esportazione si accorga dell'interruzione
    abandonFastExport();
    exp.running = false;
    $('#exportDlg').close();
    seek(0);
    toast('Esportazione interrotta');
    return;
  }
  exp.running = false;
  pause();
  if (exp.rec && exp.rec.state !== 'inactive') exp.rec.stop();
  $('#exportDlg').close();
  toast('Esportazione interrotta');
}

/* =========================================================
 * Collegamento interfaccia
 * ======================================================= */
function setupUI() {
  $('#btnAddMedia').onclick = () => $('#fileMedia').click();
  $('#btnAddMusic').onclick = () => $('#fileMusic').click();
  $('#fileMedia').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
  $('#fileMusic').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
  $('#btnProject').onclick = () => select(null);
  $('#btnNew').onclick = newProject;
  $('#btnExport').onclick = openExport;
  $('#btnPlay').onclick = togglePlay;
  $('#btnStart').onclick = () => seek(0);
  $('#btnEnd').onclick = () => seek(total);
  $('#btnPrevClip').onclick = () => jumpClip(-1);
  $('#btnNextClip').onclick = () => jumpClip(1);
  document.querySelectorAll('[data-click]').forEach(b => { b.onclick = () => $(b.dataset.click).click(); });
  const zoomBy = f => {
    const z = $('#zoom');
    z.value = clamp(Number(z.value) * f, Number(z.min), Number(z.max));
    z.dispatchEvent(new Event('input'));
  };
  $('#zoomIn').onclick = () => zoomBy(1.25);
  $('#zoomOut').onclick = () => zoomBy(1 / 1.25);
  // cursori: colora la parte già "piena"
  document.addEventListener('input', e => { if (e.target.type === 'range') paintRange(e.target); });

  const sb = $('#seekBar');
  sb.addEventListener('input', () => { seekDragging = true; seek(sb.value / 1000 * total); });
  sb.addEventListener('change', () => { seekDragging = false; });

  // Rotellina del mouse sulla timeline: scorre le clip in orizzontale.
  // Ctrl + rotellina (o pizzico sul touchpad) = zoom, centrato sul puntatore.
  document.querySelector('.timeline').addEventListener('wheel', e => {
    const sc = $('#tlScroll');
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const z = $('#zoom');
      const rect = sc.getBoundingClientRect();
      const mx = clamp(e.clientX - rect.left, 0, sc.clientWidth);
      const tAtMouse = (sc.scrollLeft + mx) / pps;
      const factor = Math.pow(1.0015, -e.deltaY * (e.deltaMode === 1 ? 40 : 1));
      const nz = clamp(pps * factor, Number(z.min), Number(z.max));
      if (Math.abs(nz - pps) < 0.01) return;
      pps = nz;
      z.value = nz;
      paintRange(z);
      renderTimeline();
      sc.scrollLeft = tAtMouse * pps - mx;
      return;
    }
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return; // touchpad: scorrimento orizzontale nativo
    e.preventDefault();
    const unit = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? sc.clientWidth : 1;
    sc.scrollLeft += e.deltaY * unit;
  }, { passive: false });

  $('#zoom').addEventListener('input', e => {
    const sc = $('#tlScroll');
    const centerT = (sc.scrollLeft + sc.clientWidth / 2) / pps;
    pps = Number(e.target.value);
    renderTimeline();
    sc.scrollLeft = centerT * pps - sc.clientWidth / 2;
  });

  // Esportazione
  $('#expStart').onclick = startExport;
  $('#expMode').onchange = updateExportMode;
  $('#expCancelSetup').onclick = () => $('#exportDlg').close();
  $('#expAbort').onclick = abortExport;
  $('#expClose').onclick = () => $('#exportDlg').close();
  $('#exportDlg').addEventListener('cancel', e => { if (exp.running) e.preventDefault(); });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && exp.running && exp.mode === 'realtime') {
      $('#expStatus').textContent = '⚠ Scheda nascosta: torna qui, altrimenti il video si blocca!';
    }
  });

  // Trascinamento file dal computer
  const overlay = $('#dropOverlay');
  let dragDepth = 0;
  const hasFiles = e => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  window.addEventListener('dragenter', e => { if (hasFiles(e)) { dragDepth++; overlay.hidden = false; } });
  window.addEventListener('dragleave', e => { if (hasFiles(e) && --dragDepth <= 0) { dragDepth = 0; overlay.hidden = true; } });
  window.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('drop', e => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth = 0; overlay.hidden = true;
    addFiles(e.dataTransfer.files);
  });

  // Tastiera
  window.addEventListener('keydown', e => {
    if ($('#exportDlg').open || $('#askDlg').open) return;
    // Ctrl+S / Ctrl+Shift+S / Ctrl+O (solo versione Linux)
    if (DESKTOP && (e.ctrlKey || e.metaKey) && !e.altKey) {
      const k = e.key.toLowerCase();
      if (k === 's') { e.preventDefault(); fileCommand(e.shiftKey ? 'saveAs' : 'save'); return; }
      if (k === 'o') { e.preventDefault(); fileCommand('open'); return; }
    }
    const tag = e.target.tagName;
    const typing = tag === 'SELECT' || tag === 'TEXTAREA' || (tag === 'INPUT' && !['range', 'checkbox'].includes(e.target.type));
    if (typing) return;
    if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
    else if ((e.key === 'Delete' || e.key === 'Backspace') && selected) { e.preventDefault(); actions.remove(); }
    else if (e.key === 'ArrowLeft' && e.target.type !== 'range') { e.preventDefault(); e.shiftKey ? jumpClip(-1) : seek(player.t - 0.1); }
    else if (e.key === 'ArrowRight' && e.target.type !== 'range') { e.preventDefault(); e.shiftKey ? jumpClip(1) : seek(player.t + 0.1); }
  });

  // avvisa solo se c'è ancora qualcosa da salvare
  window.addEventListener('beforeunload', e => {
    if (saveTimer) saveProject();
    if (DESKTOP && proj.dirty && (clips.length || music.length)) { e.preventDefault(); e.returnValue = ''; }
    if (pendingFiles.size) { e.preventDefault(); e.returnValue = ''; }
  });

  setupTimelineEvents();
}
let seekDragging = false;

setupUI();
setupDesktop();
applyCanvasSize();
relayout();
renderTimeline();
buildPanel();
render();
paintRanges();
restoreProject();

// Accesso per test automatici / console
window.editor = { clips, music, settings, player, seek, play, pause, addFiles, get total() { return total; }, exp, proj, fileCommand };
